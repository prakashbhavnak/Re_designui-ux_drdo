import { useState, useEffect, createContext, useContext } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  LayoutDashboard, Plus, Library, Package, FileText, Bell, Settings as SettingsIcon,
  User, HelpCircle, Search, ChevronRight, ChevronDown, ChevronLeft, X, Check,
  AlertTriangle, Info, Download, Trash2, Edit2, Copy, Eye, Grid, List, Upload,
  Save, Play, ZoomIn, ZoomOut, RotateCcw, Anchor, Plane, Radio, Satellite, Ship,
  Zap, Activity, BarChart3, TrendingUp, Clock, MapPin, Tag, Lock, Globe,
  Thermometer, Wind, Cloud, Layers, Target, Shield, Navigation, LogOut,
  ExternalLink, MessageSquare, HelpCircle as HelpIcon, Inbox, Palette,
  Star, ArrowRight, Send, RefreshCw, Filter, Home, Bookmark, Sun, Moon, Menu,
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import { Toaster, toast } from "sonner";

// ─── Types ──────────────────────────────────────────────────────────────────
type RootScreen = "splash" | "login" | "signup" | "app";
type AppScreen =
  | "dashboard" | "create-scenario" | "scenario-library"
  | "asset-library" | "reports" | "notifications"
  | "settings" | "profile" | "help" | "component-library";

// ─── Theme ───────────────────────────────────────────────────────────────────
type Theme = "dark" | "light";
const ThemeCtx = createContext<{ theme: Theme; toggle: () => void }>({ theme: "dark", toggle: () => {} });
const useTheme = () => useContext(ThemeCtx);

function useChartColors() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  return {
    grid: isDark ? "#323A44" : "#C8D4DC",
    axis: isDark ? "#7B8794" : "#4E6272",
    tooltip: {
      background: isDark ? "#252C34" : "#FFFFFF",
      border: `1px solid ${isDark ? "#323A44" : "#C8D4DC"}`,
      color: isDark ? "#E8EDF2" : "#1A2630",
      borderRadius: 10,
      fontSize: 12,
    } as React.CSSProperties,
  };
}

// ─── Shared UI ───────────────────────────────────────────────────────────────

function Btn({
  variant = "primary", size = "md", onClick, children, className = "", disabled = false, icon,
}: {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  onClick?: () => void;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  icon?: React.ReactNode;
}) {
  const base = "inline-flex items-center gap-2 font-medium rounded-xl transition-all duration-150 cursor-pointer select-none shrink-0";
  const sz = { sm: "px-3 py-1.5 text-xs", md: "px-4 py-2.5 text-sm", lg: "px-5 py-3 text-sm" }[size];
  const vs = {
    primary: "bg-primary text-primary-foreground hover:bg-primary/85 active:scale-95",
    secondary: "bg-card text-foreground border border-border hover:bg-card-foreground/5 active:scale-95",
    ghost: "text-dim hover:text-foreground hover:bg-card active:scale-95",
    danger: "bg-destructive/20 text-destructive border border-destructive/30 hover:bg-destructive/30 active:scale-95",
  }[variant];
  return (
    <button onClick={onClick} disabled={disabled}
      className={`${base} ${sz} ${vs} ${disabled ? "opacity-40 pointer-events-none" : ""} ${className}`}>
      {icon && <span className="shrink-0">{icon}</span>}
      {children}
    </button>
  );
}

function Field({
  label, placeholder, value, onChange, type = "text", icon, className = "", rows,
}: {
  label?: string; placeholder?: string; value?: string; onChange?: (v: string) => void;
  type?: string; icon?: React.ReactNode; className?: string; rows?: number;
}) {
  const cls = "w-full bg-card border border-border rounded-xl text-foreground placeholder-muted-foreground outline-none transition-all focus:border-primary focus:ring-1 focus:ring-primary/20 text-sm";
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      {label && <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{label}</label>}
      <div className="relative">
        {icon && <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground z-10">{icon}</span>}
        {rows ? (
          <textarea rows={rows} value={value} onChange={e => onChange?.(e.target.value)}
            placeholder={placeholder}
            className={`${cls} px-4 py-3 resize-none`} />
        ) : (
          <input type={type} value={value} onChange={e => onChange?.(e.target.value)}
            placeholder={placeholder}
            className={`${cls} h-12 ${icon ? "pl-10 pr-4" : "px-4"}`} />
        )}
      </div>
    </div>
  );
}

function Sel({
  label, value, onChange, options, className = "",
}: {
  label?: string; value?: string; onChange?: (v: string) => void;
  options: { label: string; value: string }[]; className?: string;
}) {
  return (
    <div className={`flex flex-col gap-1.5 ${className}`}>
      {label && <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">{label}</label>}
      <select value={value} onChange={e => onChange?.(e.target.value)}
        className="h-12 bg-card border border-border rounded-xl text-foreground px-4 text-sm outline-none focus:border-primary cursor-pointer">
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function Badge({
  children, variant = "default",
}: { children: React.ReactNode; variant?: "default" | "success" | "warning" | "danger" | "info" }) {
  const vs = {
    default: "bg-border text-dim",
    success: "bg-success/20 text-success",
    warning: "bg-warning/20 text-warning",
    danger: "bg-destructive/20 text-destructive",
    info: "bg-primary/20 text-primary",
  }[variant];
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium ${vs}`}>{children}</span>
  );
}

function SCard({
  children, className = "", onClick,
}: { children: React.ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div onClick={onClick}
      className={`bg-card border border-border rounded-xl ${onClick ? "cursor-pointer hover:border-primary/40 transition-colors" : ""} ${className}`}>
      {children}
    </div>
  );
}

// ─── Tactical Background ─────────────────────────────────────────────────────

function TacticalBg() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const p = isDark ? "92,169,199" : "62,143,168";
  const g = (a: number) => `rgba(${p},${a})`;

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none select-none" aria-hidden>

      {/* Tactical grid */}
      <svg className="absolute inset-0 w-full h-full">
        <defs>
          <pattern id="bg-grid-sm" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M40 0H0V40" fill="none" stroke={g(isDark ? 0.06 : 0.09)} strokeWidth="0.5"/>
          </pattern>
          <pattern id="bg-grid-lg" width="160" height="160" patternUnits="userSpaceOnUse">
            <path d="M160 0H0V160" fill="none" stroke={g(isDark ? 0.1 : 0.13)} strokeWidth="1"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#bg-grid-sm)"/>
        <rect width="100%" height="100%" fill="url(#bg-grid-lg)"/>

        {/* Static connection lines between nodes */}
        <line x1="22%" y1="58%" x2="55%" y2="32%" stroke={g(0.18)} strokeWidth="1" strokeDasharray="6 5"/>
        <line x1="55%" y1="32%" x2="78%" y2="62%" stroke={g(0.14)} strokeWidth="1" strokeDasharray="6 5"/>
        <line x1="22%" y1="58%" x2="38%" y2="76%" stroke="rgba(79,167,106,0.18)" strokeWidth="1" strokeDasharray="4 6"/>
        <line x1="78%" y1="22%" x2="55%" y2="32%" stroke="rgba(110,143,184,0.16)" strokeWidth="1" strokeDasharray="6 5"/>
        <line x1="38%" y1="76%" x2="78%" y2="62%" stroke={g(0.1)} strokeWidth="1" strokeDasharray="4 8"/>

        {/* Range rings on radar */}
        {[70, 120, 170, 220].map((r) => (
          <circle key={r} cx="22%" cy="50%" r={r}
            fill="none" stroke={g(0.07)} strokeWidth="1"/>
        ))}
        {/* Cross-hairs */}
        <line x1="0" y1="50%" x2="44%" y2="50%" stroke={g(0.06)} strokeWidth="1"/>
        <line x1="22%" y1="0" x2="22%" y2="100%" stroke={g(0.06)} strokeWidth="1"/>
      </svg>

      {/* Radar sweep */}
      <motion.div className="absolute rounded-full" style={{
        width: 440, height: 440,
        left: "22%", top: "50%",
        translate: "-50% -50%",
        background: `conic-gradient(from 0deg, transparent 310deg, ${g(0.05)} 345deg, ${g(0.14)} 360deg)`,
      }}
        animate={{ rotate: 360 }}
        transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
      />
      {/* Radar center dot */}
      <div className="absolute w-2.5 h-2.5 rounded-full" style={{
        left: "22%", top: "50%", translate: "-50% -50%",
        background: g(0.7), boxShadow: `0 0 10px ${g(0.5)}`,
      }}/>

      {/* Gradient vignette so form stays readable */}
      <div className="absolute inset-0" style={{
        background: isDark
          ? "radial-gradient(ellipse 55% 80% at 70% 50%, transparent 0%, rgba(22,26,31,0.7) 100%)"
          : "radial-gradient(ellipse 55% 80% at 70% 50%, transparent 0%, rgba(238,242,246,0.75) 100%)",
      }}/>

      {/* Ambient glow orbs */}
      <motion.div className="absolute rounded-full blur-3xl" style={{
        width: 480, height: 480, left: "-8%", top: "20%",
        background: `radial-gradient(circle, ${g(isDark ? 0.2 : 0.12)} 0%, transparent 70%)`,
        opacity: 0.8,
      }}
        animate={{ x: [0, 24, 0], y: [0, 16, 0] }}
        transition={{ duration: 14, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div className="absolute rounded-full blur-3xl" style={{
        width: 360, height: 360, right: "2%", bottom: "10%",
        background: `radial-gradient(circle, rgba(110,143,184,${isDark ? 0.22 : 0.12}) 0%, transparent 70%)`,
        opacity: 0.7,
      }}
        animate={{ x: [0, -18, 0], y: [0, -24, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut", delay: 3 }}
      />

      {/* ── Asset nodes ── */}

      {/* Node 1 — Maritime (ship) */}
      <motion.div className="absolute" style={{ left: "22%", top: "58%" }}
        animate={{ x: [0, 55, 110, 75, 0], y: [0, -18, 8, 26, 0] }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}>
        <div className="w-3 h-3 rounded-full" style={{ background: g(0.85), boxShadow: `0 0 10px ${g(0.6)}` }}/>
        <div className="absolute top-4 left-0 text-[9px] font-mono whitespace-nowrap" style={{ color: g(0.55) }}>CVN-78 · ACTIVE</div>
        <motion.div className="absolute rounded-full border" style={{ width: 26, height: 26, top: -7, left: -7, borderColor: g(0.35) }}
          animate={{ scale: [1, 1.9, 1], opacity: [0.5, 0, 0.5] }}
          transition={{ duration: 2.8, repeat: Infinity }}/>
      </motion.div>

      {/* Node 2 — Air asset */}
      <motion.div className="absolute" style={{ left: "78%", top: "22%" }}
        animate={{ x: [0, -35, -70, -35, 0], y: [0, 28, 55, 28, 0] }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}>
        <div className="w-2.5 h-2.5 rounded-full" style={{ background: "rgba(110,143,184,0.9)", boxShadow: "0 0 8px rgba(110,143,184,0.6)" }}/>
        <div className="absolute top-4 left-0 text-[9px] font-mono whitespace-nowrap" style={{ color: "rgba(110,143,184,0.55)" }}>FA-18 · INBOUND</div>
      </motion.div>

      {/* Node 3 — Target (threat, stationary pulsing) */}
      <div className="absolute" style={{ left: "78%", top: "62%" }}>
        <div className="w-3 h-3 rounded-full" style={{ background: "rgba(201,106,106,0.9)", boxShadow: "0 0 12px rgba(201,106,106,0.6)" }}/>
        <motion.div className="absolute rounded-full border border-red-400/40" style={{ width: 30, height: 30, top: -9, left: -9 }}
          animate={{ scale: [1, 1.7, 1], opacity: [0.6, 0, 0.6] }}
          transition={{ duration: 1.8, repeat: Infinity }}/>
        <motion.div className="absolute rounded-full border border-red-400/20" style={{ width: 50, height: 50, top: -19, left: -19 }}
          animate={{ scale: [1, 1.5, 1], opacity: [0.3, 0, 0.3] }}
          transition={{ duration: 1.8, repeat: Infinity, delay: 0.6 }}/>
        <div className="absolute top-4 left-0 text-[9px] font-mono whitespace-nowrap" style={{ color: "rgba(201,106,106,0.6)" }}>TGT-04 · HOSTILE</div>
      </div>

      {/* Node 4 — USV (friendly) */}
      <motion.div className="absolute" style={{ left: "38%", top: "76%" }}
        animate={{ x: [0, 28, 0], y: [0, -14, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: "easeInOut", delay: 4 }}>
        <div className="w-2.5 h-2.5 rounded-full" style={{ background: "rgba(79,167,106,0.9)", boxShadow: "0 0 8px rgba(79,167,106,0.5)" }}/>
        <div className="absolute top-4 left-0 text-[9px] font-mono whitespace-nowrap" style={{ color: "rgba(79,167,106,0.55)" }}>USV-12 · PATROL</div>
      </motion.div>

      {/* Node 5 — Satellite */}
      <motion.div className="absolute" style={{ left: "55%", top: "32%" }}
        animate={{ x: [0, 22, 44, 22, 0], y: [0, 12, 0, -12, 0] }}
        transition={{ duration: 16, repeat: Infinity, ease: "easeInOut", delay: 1 }}>
        <div className="w-2 h-2 rounded-full" style={{ background: g(0.7), boxShadow: `0 0 7px ${g(0.45)}` }}/>
        <div className="absolute top-3 left-0 text-[9px] font-mono whitespace-nowrap" style={{ color: g(0.45) }}>SAT-03 · ISR</div>
      </motion.div>

      {/* ── Scan line ── */}
      <motion.div className="absolute left-0 right-0 h-px" style={{
        background: `linear-gradient(90deg, transparent 0%, ${g(0.2)} 30%, ${g(0.3)} 50%, ${g(0.2)} 70%, transparent 100%)`,
      }}
        initial={{ top: "0%" }}
        animate={{ top: ["0%", "102%"] }}
        transition={{ duration: 9, repeat: Infinity, ease: "linear", repeatDelay: 3 }}
      />

      {/* ── Corner HUD ── */}
      <div className="absolute top-16 left-4 font-mono text-[9px] leading-relaxed" style={{ color: g(0.4) }}>
        <div>LAT 36°42′24″N</div>
        <div>LON 121°56′16″W</div>
        <div>GRID 10S EJ 9456 1234</div>
      </div>
      <div className="absolute top-16 right-4 text-right font-mono text-[9px] leading-relaxed" style={{ color: g(0.4) }}>
        <div>TS // SCI // NOFORN</div>
        <div>OPS STATUS: ACTIVE</div>
        <div>THEATER: PACIFIC AOR</div>
      </div>
      <div className="absolute bottom-4 left-4 font-mono text-[9px] leading-relaxed" style={{ color: g(0.28) }}>
        <div>SCENARIO BUILDER v4.2.1</div>
        <div>NAVSPECWARCOM J3</div>
      </div>
      <div className="absolute bottom-4 right-4 text-right font-mono text-[9px] leading-relaxed" style={{ color: g(0.28) }}>
        <div>ASSETS TRACKED: 5</div>
        <div>THREATS: 1 HOSTILE</div>
      </div>
    </div>
  );
}

// ─── Splash ──────────────────────────────────────────────────────────────────

function ThemeToggleBtn({ size = 16 }: { size?: number }) {
  const { theme, toggle } = useTheme();
  return (
    <motion.button
      onClick={toggle}
      whileTap={{ scale: 0.88 }}
      title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
      className="relative w-9 h-9 rounded-xl border border-border bg-card flex items-center justify-center text-dim hover:text-foreground hover:border-primary/50 hover:bg-muted transition-all duration-300"
    >
      <AnimatePresence mode="wait" initial={false}>
        {theme === "dark" ? (
          <motion.span key="sun"
            initial={{ opacity: 0, rotate: -30, scale: 0.7 }}
            animate={{ opacity: 1, rotate: 0, scale: 1 }}
            exit={{ opacity: 0, rotate: 30, scale: 0.7 }}
            transition={{ duration: 0.18 }}
            className="absolute flex items-center justify-center"
          >
            <Sun size={size} />
          </motion.span>
        ) : (
          <motion.span key="moon"
            initial={{ opacity: 0, rotate: 30, scale: 0.7 }}
            animate={{ opacity: 1, rotate: 0, scale: 1 }}
            exit={{ opacity: 0, rotate: -30, scale: 0.7 }}
            transition={{ duration: 0.18 }}
            className="absolute flex items-center justify-center"
          >
            <Moon size={size} />
          </motion.span>
        )}
      </AnimatePresence>
    </motion.button>
  );
}

function SplashScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(id); setTimeout(onDone, 500); return 100; }
        return p + 1.5;
      });
    }, 30);
    return () => clearInterval(id);
  }, [onDone]);

  return (
    <div className="w-full h-full bg-background flex flex-col relative overflow-hidden transition-colors duration-300">
      {/* Top nav */}
      <nav className="absolute top-0 inset-x-0 z-20 h-14 border-b border-border bg-background/80 backdrop-blur-md flex items-center justify-between px-6 transition-colors duration-300">
        <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}
          className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center shadow-sm shadow-primary/30">
            <Target size={14} className="text-primary-foreground" />
          </div>
          <span className="text-xs font-bold text-foreground tracking-widest uppercase">Scenario Builder</span>
          <span className="ml-2 px-2 py-0.5 rounded-md bg-primary/10 text-primary text-[10px] font-bold tracking-wider border border-primary/20">LOADING</span>
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}
          className="flex items-center gap-3">
          <span className="text-[11px] text-muted-foreground hidden sm:block">v4.2.1</span>
          <ThemeToggleBtn />
        </motion.div>
      </nav>

      {/* Grid */}
      <div className="absolute inset-0 pointer-events-none" style={{
        backgroundImage: "linear-gradient(rgba(92,169,199,0.05) 1px,transparent 1px),linear-gradient(90deg,rgba(92,169,199,0.05) 1px,transparent 1px)",
        backgroundSize: "48px 48px",
      }} />
      {/* Radar rings */}
      {[200, 300, 400, 500].map((r, i) => (
        <motion.div key={r}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border border-primary/10"
          style={{ width: r, height: r }}
          animate={{ scale: [1, 1.04, 1], opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 3.5, delay: i * 0.6, repeat: Infinity }} />
      ))}
      {/* Sweep */}
      <motion.div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none"
        style={{ width: 480, height: 480, background: "conic-gradient(from 0deg,transparent 300deg,rgba(92,169,199,0.15) 360deg)" }}
        animate={{ rotate: 360 }}
        transition={{ duration: 5, repeat: Infinity, ease: "linear" }} />

      <div className="flex-1 flex flex-col items-center justify-center relative z-10">
        <div className="flex flex-col items-center gap-10">
          <motion.div initial={{ opacity: 0, y: -24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}
            className="flex items-center gap-4">
            <div className="w-14 h-14 bg-primary rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20">
              <Target size={28} className="text-primary-foreground" />
            </div>
            <div>
              <p className="text-3xl font-bold text-foreground tracking-tight leading-none">SCENARIO BUILDER</p>
              <p className="text-muted-foreground text-xs tracking-widest uppercase mt-1">Mission Planning & Simulation Platform</p>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
            className="w-72 flex flex-col gap-2.5">
            <div className="w-full h-[3px] bg-muted rounded-full overflow-hidden">
              <motion.div className="h-full bg-gradient-to-r from-primary to-chart-2 rounded-full"
                style={{ width: `${progress}%` }} transition={{ ease: "linear" }} />
            </div>
            <div className="flex justify-between">
              <span className="text-xs text-muted-foreground">
                {progress < 30 ? "Authenticating systems..." : progress < 60 ? "Loading asset registry..." : progress < 90 ? "Preparing workspace..." : "Ready"}
              </span>
              <span className="text-xs text-primary font-medium">{Math.round(progress)}%</span>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}
            className="flex gap-6 text-muted-foreground text-xs">
            <span>ITAR CONTROLLED</span>
            <span>·</span>
            <span>AUTHORIZED USE ONLY</span>
            <span>·</span>
            <span>v4.2.1</span>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

// ─── Login ────────────────────────────────────────────────────────────────────

function LoginScreen({ onLogin, onSignup }: { onLogin: () => void; onSignup: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div className="w-full h-full bg-background flex flex-col overflow-hidden transition-colors duration-300 relative">

      <TacticalBg />

      {/* Top nav bar */}
      <nav className="h-14 border-b border-border bg-card/80 backdrop-blur-md flex items-center justify-between px-6 shrink-0 z-10 transition-colors duration-300">
        <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4 }}
          className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center shadow-sm shadow-primary/30">
            <Target size={14} className="text-primary-foreground" />
          </div>
          <span className="text-xs font-bold text-foreground tracking-widest uppercase">Scenario Builder</span>
          <span className="ml-2 px-2 py-0.5 rounded-md bg-destructive/15 text-destructive text-[10px] font-bold tracking-wider border border-destructive/20">ITAR CONTROLLED</span>
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4 }}
          className="flex items-center gap-3">
          <span className="text-[11px] text-muted-foreground hidden sm:block">v4.2.1</span>
          <ThemeToggleBtn />
        </motion.div>
      </nav>

      {/* Centered form */}
      <div className="flex-1 flex items-center justify-center p-6 relative z-10">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45, ease: "easeOut" }}
          className="w-full max-w-[420px] bg-card/80 backdrop-blur-xl border border-border rounded-2xl p-8 shadow-2xl shadow-black/10">
          <div className="flex items-center gap-2.5 mb-8">
            <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center shadow-md shadow-primary/30">
              <Target size={18} className="text-primary-foreground" />
            </div>
            <span className="font-bold text-foreground tracking-tight">SCENARIO BUILDER</span>
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-1">Welcome back</h2>
          <p className="text-muted-foreground text-sm mb-7">Sign in to your authorized account</p>

          <div className="flex flex-col gap-4">
            <Field label="Email / Identifier" placeholder="operator@domain.mil" type="email"
              value={email} onChange={setEmail} icon={<User size={14} />} />
            <Field label="Password" placeholder="••••••••••" type="password"
              value={password} onChange={setPassword} icon={<Lock size={14} />} />
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" className="w-4 h-4 rounded accent-[#5CA9C7]" />
                <span className="text-xs text-dim">Remember this device</span>
              </label>
              <button className="text-xs text-primary hover:underline">Forgot password?</button>
            </div>
            <Btn size="lg" className="w-full justify-center mt-1"
              onClick={() => { if (email && password) { onLogin(); } else { toast.error("Enter credentials to continue"); } }}>
              Sign In
            </Btn>
            <Btn variant="secondary" size="lg" className="w-full justify-center">
              Continue with SSO
            </Btn>
          </div>

          <p className="text-center mt-6 text-xs text-muted-foreground">
            Need access?{" "}
            <button onClick={onSignup} className="text-primary hover:underline">Request account</button>
          </p>
          <div className="mt-6 pt-5 border-t border-border flex justify-center gap-6">
            <span className="text-xs text-muted-foreground">ITAR CONTROLLED</span>
            <span className="text-xs text-border">·</span>
            <span className="text-xs text-muted-foreground">AUTHORIZED USE ONLY</span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

// ─── Sign Up ─────────────────────────────────────────────────────────────────

function SignupScreen({ onBack, onDone }: { onBack: () => void; onDone: () => void }) {
  const [form, setForm] = useState({ name: "", org: "", email: "", password: "", confirm: "" });
  const f = (k: keyof typeof form) => (v: string) => setForm(s => ({ ...s, [k]: v }));

  return (
    <div className="w-full h-full bg-background flex flex-col overflow-hidden transition-colors duration-300">
      {/* Top nav */}
      <nav className="h-14 border-b border-border bg-card flex items-center justify-between px-6 shrink-0 transition-colors duration-300">
        <motion.div initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4 }}
          className="flex items-center gap-2.5">
          <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center shadow-sm shadow-primary/30">
            <Target size={14} className="text-primary-foreground" />
          </div>
          <span className="text-xs font-bold text-foreground tracking-widest uppercase">Scenario Builder</span>
          <span className="ml-2 px-2 py-0.5 rounded-md bg-destructive/15 text-destructive text-[10px] font-bold tracking-wider border border-destructive/20">ITAR CONTROLLED</span>
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4 }}
          className="flex items-center gap-3">
          <span className="text-[11px] text-muted-foreground hidden sm:block">v4.2.1</span>
          <ThemeToggleBtn />
        </motion.div>
      </nav>

      {/* Center card */}
      <div className="flex-1 flex items-center justify-center p-6">
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
        className="w-[520px] bg-muted border border-border rounded-2xl p-8">
        <div className="flex items-center gap-2.5 mb-8">
          <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center">
            <Target size={18} className="text-primary-foreground" />
          </div>
          <span className="font-bold text-foreground tracking-tight">SCENARIO BUILDER</span>
        </div>
        <h2 className="text-2xl font-bold text-foreground mb-1">Request Access</h2>
        <p className="text-muted-foreground text-sm mb-7">Submit your details for account provisioning</p>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Full Name" placeholder="Rank First Last" value={form.name} onChange={f("name")} className="col-span-2" />
          <Field label="Organization" placeholder="Unit / Command" value={form.org} onChange={f("org")} />
          <Field label="Email" placeholder="user@domain.mil" type="email" value={form.email} onChange={f("email")} />
          <Field label="Password" placeholder="Min 12 characters" type="password" value={form.password} onChange={f("password")} />
          <Field label="Confirm Password" placeholder="Repeat password" type="password" value={form.confirm} onChange={f("confirm")} />
        </div>
        <label className="flex items-start gap-2.5 mt-4 cursor-pointer">
          <input type="checkbox" className="w-4 h-4 mt-0.5 accent-[#5CA9C7] shrink-0" />
          <span className="text-xs text-muted-foreground">I acknowledge this is a classified system and agree to all applicable use policies and security obligations.</span>
        </label>
        <div className="flex gap-3 mt-6">
          <Btn variant="secondary" onClick={onBack} className="flex-1 justify-center">Back to Login</Btn>
          <Btn className="flex-1 justify-center" onClick={() => { toast.success("Access request submitted"); setTimeout(onDone, 1000); }}>
            Submit Request
          </Btn>
        </div>
      </motion.div>
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────

interface NavSub { label: string; dot?: string }
interface NavItem {
  id: AppScreen; icon: React.ReactNode; label: string;
  badge?: number; subs?: NavSub[];
}

const NAV: NavItem[] = [
  { id: "dashboard", icon: <LayoutDashboard size={18} />, label: "Dashboard",
    subs: [
      { label: "Overview", dot: "#5CA9C7" },
      { label: "Mission Status", dot: "#4FA76A" },
      { label: "Recent Activity", dot: "#6E8FB8" },
      { label: "Analytics", dot: "#D4A85E" },
    ],
  },
  { id: "create-scenario", icon: <Plus size={18} />, label: "Create Scenario",
    subs: [
      { label: "New Scenario" },
      { label: "From Template" },
      { label: "Duplicate Existing" },
    ],
  },
  { id: "scenario-library", icon: <Library size={18} />, label: "Scenario Library",
    subs: [
      { label: "Active Missions", dot: "#4FA76A" },
      { label: "Drafts", dot: "#D4A85E" },
      { label: "In Review", dot: "#5CA9C7" },
      { label: "Completed", dot: "#6E8FB8" },
      { label: "Templates" },
      { label: "Archived" },
    ],
  },
  { id: "asset-library", icon: <Package size={18} />, label: "Assets",
    subs: [
      { label: "Ships" },
      { label: "Aircraft" },
      { label: "Missiles" },
      { label: "Drones" },
      { label: "Radar & Sensors" },
      { label: "Satellites" },
      { label: "Submarines" },
      { label: "Ground Units" },
    ],
  },
  { id: "reports", icon: <BarChart3 size={18} />, label: "Reports",
    subs: [
      { label: "Mission Analytics" },
      { label: "Asset Usage" },
      { label: "Performance" },
      { label: "Export History" },
    ],
  },
  { id: "notifications", icon: <Bell size={18} />, label: "Notifications", badge: 3,
    subs: [
      { label: "Inbox", dot: "#5CA9C7" },
      { label: "Mentions" },
      { label: "System Alerts", dot: "#D4A85E" },
    ],
  },
];

const NAV_BOTTOM: NavItem[] = [
  { id: "component-library", icon: <Palette size={18} />, label: "UI Components" },
  { id: "settings", icon: <SettingsIcon size={18} />, label: "Settings",
    subs: [
      { label: "Profile" },
      { label: "Security" },
      { label: "Preferences" },
      { label: "API Keys" },
    ],
  },
  { id: "profile", icon: <User size={18} />, label: "Profile" },
  { id: "help", icon: <HelpCircle size={18} />, label: "Help" },
];

function Sidebar({
  active, onNav, collapsed, onToggle, isMobile, onMobileClose,
}: { active: AppScreen; onNav: (s: AppScreen) => void; collapsed: boolean; onToggle: () => void; isMobile?: boolean; onMobileClose?: () => void }) {
  const [expanded, setExpanded] = useState<string | null>("dashboard");

  const toggleExpand = (id: string) => {
    setExpanded(prev => prev === id ? null : id);
  };

  const renderItem = (item: NavItem, isBottom = false) => {
    const isActive = active === item.id;
    const isOpen = expanded === item.id && !collapsed;
    const hasSubs = item.subs && item.subs.length > 0;

    return (
      <div key={item.id}>
        <button
          onClick={() => {
            onNav(item.id);
            if (hasSubs && !collapsed) toggleExpand(item.id);
          }}
          className={`relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-left w-full transition-all duration-150 group
            ${isActive ? "bg-sidebar-primary/12 text-sidebar-primary" : "text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent"}`}
        >
          {isActive && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-sidebar-primary rounded-r-full" />}
          <span className="shrink-0">{item.icon}</span>
          {!collapsed && (
            <>
              <span className="text-sm font-medium whitespace-nowrap flex-1">{item.label}</span>
              {item.badge && (
                <span className="bg-sidebar-primary text-sidebar-primary-foreground text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                  {item.badge}
                </span>
              )}
              {hasSubs && !item.badge && (
                <span className={`shrink-0 transition-transform duration-200 ${isOpen ? "rotate-180" : "rotate-0"}`}>
                  <ChevronDown size={14} className="text-sidebar-foreground/40" />
                </span>
              )}
            </>
          )}
          {item.badge && collapsed && (
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-sidebar-primary rounded-full" />
          )}
        </button>

        {/* Sub-items */}
        {hasSubs && !collapsed && (
          <AnimatePresence initial={false}>
            {isOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: "easeInOut" }}
                className="overflow-hidden"
              >
                <div className="ml-4 mt-0.5 mb-1 border-l border-sidebar-border pl-3 flex flex-col gap-0.5">
                  {item.subs!.map(sub => (
                    <button
                      key={sub.label}
                      onClick={() => onNav(item.id)}
                      className="flex items-center gap-2 px-2 py-1.5 rounded-lg text-left w-full text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-all duration-100 group"
                    >
                      {sub.dot
                        ? <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: sub.dot }} />
                        : <span className="w-1.5 h-1.5 rounded-full bg-sidebar-border shrink-0 group-hover:bg-sidebar-foreground/40 transition-colors" />
                      }
                      <span className="text-xs font-medium whitespace-nowrap">{sub.label}</span>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>
    );
  };

  const showLabels = !collapsed || isMobile;

  return (
    <motion.aside
      animate={{ width: isMobile ? 280 : collapsed ? 88 : 280 }}
      className="h-full bg-sidebar border-r border-sidebar-border flex flex-col shrink-0 overflow-hidden transition-colors duration-300"
      style={{ minWidth: isMobile ? 280 : collapsed ? 88 : 280 }}
    >
      {/* Logo */}
      <div className="h-[72px] flex items-center px-5 border-b border-sidebar-border shrink-0">
        <div className="w-9 h-9 bg-sidebar-primary rounded-xl flex items-center justify-center shrink-0 shadow-md shadow-sidebar-primary/20">
          <Target size={18} className="text-sidebar-primary-foreground" />
        </div>
        {showLabels && (
          <span className="ml-3 font-bold text-sidebar-foreground text-sm tracking-wide whitespace-nowrap flex-1">SCENARIO BUILDER</span>
        )}
        {isMobile && (
          <button onClick={onMobileClose} className="w-8 h-8 rounded-lg flex items-center justify-center text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-all">
            <X size={16} />
          </button>
        )}
      </div>

      {/* Main nav */}
      <nav className="flex-1 py-3 px-2.5 flex flex-col gap-0.5 overflow-y-auto">
        {NAV.map(item => renderItem(item))}
      </nav>

      {/* Bottom nav */}
      <div className="border-t border-sidebar-border py-3 px-2.5 flex flex-col gap-0.5">
        {NAV_BOTTOM.map(item => renderItem(item, true))}
        {!isMobile && (
          <button
            onClick={onToggle}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent transition-all w-full"
          >
            <span className="shrink-0">{collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}</span>
            {!collapsed && <span className="text-sm font-medium">Collapse</span>}
          </button>
        )}
      </div>
    </motion.aside>
  );
}

// ─── TopBar ───────────────────────────────────────────────────────────────────

const TITLES: Record<AppScreen, string> = {
  dashboard: "Dashboard",
  "create-scenario": "Create Scenario",
  "scenario-library": "Scenario Library",
  "asset-library": "Asset Library",
  reports: "Reports & Analytics",
  notifications: "Notifications",
  settings: "Settings",
  profile: "Profile",
  help: "Help & Documentation",
  "component-library": "UI Component Library",
};

function TopBar({ screen, onMenuOpen }: { screen: AppScreen; onMenuOpen?: () => void }) {
  const { theme, toggle } = useTheme();
  return (
    <header className="h-[72px] bg-card border-b border-border flex items-center px-4 md:px-6 gap-3 md:gap-4 shrink-0 transition-colors duration-300">
      <button
        onClick={onMenuOpen}
        className="md:hidden w-9 h-9 rounded-lg border border-border bg-card flex items-center justify-center text-dim hover:text-foreground transition-colors shrink-0"
      >
        <Menu size={18} />
      </button>
      <h1 className="text-base font-semibold text-foreground mr-auto truncate">{TITLES[screen]}</h1>
      <div className="relative hidden sm:block">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input placeholder="Search scenarios, assets..."
          className="w-40 md:w-52 h-9 bg-card border border-border rounded-lg pl-8 pr-3 text-xs text-foreground placeholder-muted-foreground outline-none focus:border-primary transition-colors" />
      </div>
      <button
        onClick={toggle}
        title={theme === "dark" ? "Switch to light mode" : "Switch to dark mode"}
        className="w-9 h-9 rounded-lg border border-border bg-card flex items-center justify-center text-dim hover:text-foreground transition-colors"
      >
        {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
      </button>
      <button className="relative w-9 h-9 rounded-lg border border-border bg-card flex items-center justify-center text-dim hover:text-foreground transition-colors">
        <Bell size={16} />
        <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-primary rounded-full" />
      </button>
      <div className="flex items-center gap-2.5 pl-3 border-l border-border">
        <div className="w-8 h-8 rounded-full bg-primary/15 border border-primary/40 flex items-center justify-center text-primary text-xs font-bold">
          OC
        </div>
        <div>
          <p className="text-xs font-semibold text-foreground leading-none">Operator Cmdr.</p>
          <p className="text-[10px] text-muted-foreground leading-none mt-0.5">TOP SECRET · SCI</p>
        </div>
      </div>
    </header>
  );
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

const areaData = [
  { m: "Jan", sc: 12, as: 45 }, { m: "Feb", sc: 18, as: 52 }, { m: "Mar", sc: 14, as: 48 },
  { m: "Apr", sc: 24, as: 67 }, { m: "May", sc: 21, as: 71 }, { m: "Jun", sc: 32, as: 89 },
  { m: "Jul", sc: 28, as: 95 },
];
const pieData = [
  { name: "Maritime", value: 35, color: "#5CA9C7" },
  { name: "Aviation", value: 28, color: "#6E8FB8" },
  { name: "Ground", value: 20, color: "#4FA76A" },
  { name: "Space", value: 17, color: "#D4A85E" },
];
const recentScenarios = [
  { id: 1, name: "Operation Neptune Strike", type: "Maritime", status: "active", entities: 24, ago: "2h", priority: "High" },
  { id: 2, name: "Arctic Falcon Intercept", type: "Aviation", status: "draft", entities: 12, ago: "1d", priority: "Critical" },
  { id: 3, name: "Desert Shield Defense", type: "Ground", status: "complete", entities: 38, ago: "3d", priority: "Medium" },
  { id: 4, name: "Orbital Surveillance Net", type: "Space", status: "review", entities: 8, ago: "5d", priority: "Low" },
];
const domainIcon = (t: string) =>
  t === "Maritime" ? <Ship size={14} /> : t === "Aviation" ? <Plane size={14} /> : t === "Space" ? <Satellite size={14} /> : <Shield size={14} />;

function Dashboard({ onNav }: { onNav: (s: AppScreen) => void }) {
  const cc = useChartColors();
  return (
    <div className="flex-1 flex overflow-hidden">
      <div className="flex-1 overflow-y-auto p-6 space-y-5">
        {/* Header */}
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-xl font-bold text-foreground">Good morning, Commander</h2>
            <p className="text-muted-foreground text-sm mt-0.5">3 missions require attention · Refreshed 2 min ago</p>
          </div>
          <Btn onClick={() => onNav("create-scenario")} icon={<Plus size={14} />}>New Scenario</Btn>
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Total Scenarios", value: "247", delta: "+12%", icon: <FileText size={18} />, color: "#5CA9C7" },
            { label: "Active Missions", value: "18", delta: "+3", icon: <Activity size={18} />, color: "#4FA76A" },
            { label: "Total Assets", value: "1,842", delta: "+89", icon: <Package size={18} />, color: "#6E8FB8" },
            { label: "Completion Rate", value: "94.2%", delta: "+2.1%", icon: <TrendingUp size={18} />, color: "#D4A85E" },
          ].map(m => (
            <SCard key={m.label} className="p-5 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span style={{ color: m.color }}>{m.icon}</span>
                <Badge variant="success">{m.delta}</Badge>
              </div>
              <div>
                <p className="text-2xl font-bold text-foreground">{m.value}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{m.label}</p>
              </div>
            </SCard>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-3 gap-4">
          <SCard className="col-span-2 p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-foreground">Mission Activity</h3>
              <div className="flex gap-1.5">
                {["7M", "3M", "1Y"].map(t => (
                  <button key={t}
                    className={`text-xs px-2.5 py-1 rounded-lg transition-colors ${t === "7M" ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={areaData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
                <CartesianGrid key="grid" strokeDasharray="3 3" stroke={cc.grid} />
                <XAxis key="x" dataKey="m" stroke={cc.axis} tick={{ fill: cc.axis, fontSize: 11 }} />
                <YAxis key="y" stroke={cc.axis} tick={{ fill: cc.axis, fontSize: 11 }} />
                <Tooltip key="tip" contentStyle={cc.tooltip} />
                <Area key="sc" type="monotone" dataKey="sc" stroke="#5CA9C7" fill="#5CA9C7" fillOpacity={0.15} strokeWidth={2} name="Scenarios" />
                <Area key="as" type="monotone" dataKey="as" stroke="#6E8FB8" fill="#6E8FB8" fillOpacity={0.12} strokeWidth={2} name="Assets" />
              </AreaChart>
            </ResponsiveContainer>
          </SCard>

          <SCard className="p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Domain Distribution</h3>
            <ResponsiveContainer width="100%" height={140}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={38} outerRadius={60} dataKey="value" paddingAngle={3}>
                  {pieData.map((e) => <Cell key={e.name} fill={e.color} />)}
                </Pie>
                <Tooltip key="tip" contentStyle={{ ...cc.tooltip, borderRadius: 8 }} />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-3 space-y-1.5">
              {pieData.map(d => (
                <div key={d.name} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full shrink-0" style={{ background: d.color }} />
                    <span className="text-xs text-dim">{d.name}</span>
                  </div>
                  <span className="text-xs font-semibold text-foreground">{d.value}%</span>
                </div>
              ))}
            </div>
          </SCard>
        </div>

        {/* Recent scenarios */}
        <SCard className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-foreground">Recent Scenarios</h3>
            <Btn variant="ghost" size="sm" onClick={() => onNav("scenario-library")}>View all</Btn>
          </div>
          <div className="space-y-1">
            {recentScenarios.map(s => (
              <div key={s.id}
                className="flex items-center gap-4 p-3 rounded-xl hover:bg-muted transition-colors cursor-pointer group">
                <div className="w-8 h-8 rounded-lg bg-muted border border-border flex items-center justify-center text-primary shrink-0">
                  {domainIcon(s.type)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{s.name}</p>
                  <p className="text-xs text-muted-foreground">{s.entities} entities · {s.ago} ago</p>
                </div>
                <Badge variant={s.priority === "Critical" ? "danger" : s.priority === "High" ? "warning" : "default"}>{s.priority}</Badge>
                <Badge variant={s.status === "active" ? "success" : s.status === "complete" ? "info" : s.status === "review" ? "warning" : "default"}>{s.status}</Badge>
                <button className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-primary transition-all">
                  <Edit2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </SCard>
      </div>

      {/* Right panel */}
      <aside className="w-[280px] border-l border-border flex flex-col shrink-0 bg-muted">
        <div className="p-4 border-b border-border">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Activity Feed</h3>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {[
            { msg: "Arctic Falcon mission parameters updated", time: "5m", type: "info" },
            { msg: "3 new maritime assets imported", time: "22m", type: "success" },
            { msg: "Neptune Strike package generated", time: "1h", type: "success" },
            { msg: "Validation warning in Desert Shield", time: "2h", type: "warning" },
            { msg: "Orbital Net pending CMO review", time: "3h", type: "info" },
            { msg: "Storage approaching 80% capacity", time: "4h", type: "warning" },
            { msg: "System backup completed", time: "6h", type: "success" },
          ].map((a, i) => (
            <div key={i} className="flex gap-3">
              <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0
                ${a.type === "success" ? "bg-success" : a.type === "warning" ? "bg-warning" : "bg-primary"}`} />
              <div>
                <p className="text-xs text-dim leading-snug">{a.msg}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{a.time} ago</p>
              </div>
            </div>
          ))}
        </div>
        <div className="p-4 border-t border-border">
          <div className="flex justify-between text-xs text-muted-foreground mb-2">
            <span>Storage</span><span>7.8 / 10 TB</span>
          </div>
          <div className="h-1.5 bg-card rounded-full overflow-hidden">
            <div className="h-full bg-warning rounded-full" style={{ width: "78%" }} />
          </div>
          <p className="text-[10px] text-muted-foreground mt-1.5">2.2 TB remaining</p>
        </div>
      </aside>
    </div>
  );
}

// ─── Create Scenario ──────────────────────────────────────────────────────────

const STEPS = ["General", "Environment", "Assets", "Configure", "Relationships", "Timeline", "Review", "Generate"];

const ASSET_POOL = [
  { id: 1, name: "USS Gerald R. Ford", cat: "Ships", type: "Aircraft Carrier", icon: <Ship size={20} /> },
  { id: 2, name: "F/A-18 Super Hornet", cat: "Aircraft", type: "Fighter Jet", icon: <Plane size={20} /> },
  { id: 3, name: "RQ-4 Global Hawk", cat: "Drone", type: "Surveillance UAV", icon: <Navigation size={20} /> },
  { id: 4, name: "AN/TPY-2 Radar", cat: "Radar", type: "BMD Radar System", icon: <Radio size={20} /> },
  { id: 5, name: "KH-13 Satellite", cat: "Satellite", type: "Reconnaissance Sat.", icon: <Satellite size={20} /> },
  { id: 6, name: "Virginia-class SSN", cat: "Submarine", type: "Attack Submarine", icon: <Anchor size={20} /> },
  { id: 7, name: "AIM-120 AMRAAM", cat: "Missiles", type: "Air-to-Air Missile", icon: <Zap size={20} /> },
  { id: 8, name: "M1A2 Abrams", cat: "Ground", type: "Main Battle Tank", icon: <Shield size={20} /> },
  { id: 9, name: "USS Arleigh Burke", cat: "Ships", type: "Guided Missile DDG", icon: <Ship size={20} /> },
  { id: 10, name: "B-2 Spirit", cat: "Aircraft", type: "Strategic Bomber", icon: <Plane size={20} /> },
  { id: 11, name: "MQ-9 Reaper", cat: "Drone", type: "Attack UAV", icon: <Navigation size={20} /> },
  { id: 12, name: "THAAD Battery", cat: "Radar", type: "Terminal Defense", icon: <Radio size={20} /> },
];

const ASSET_CATS = ["Ships", "Aircraft", "Missiles", "Drone", "Radar", "Satellite", "Submarine", "Ground"];

function CreateScenario({ onCancel }: { onCancel: () => void }) {
  const [step, setStep] = useState(0);
  const [cat, setCat] = useState("Ships");
  const [selected, setSelected] = useState<number[]>([]);
  const [form, setForm] = useState({ name: "", missionType: "offensive", desc: "", classification: "SECRET", location: "", priority: "high", tags: "" });
  const [env, setEnv] = useState("Ocean");
  const [wx, setWx] = useState({ wind: 15, visibility: 8, temp: 18, sea: 3 });
  const sf = (k: keyof typeof form) => (v: string) => setForm(f => ({ ...f, [k]: v }));
  const toggleAsset = (id: number) => setSelected(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  const stepContent = () => {
    if (step === 0) return (
      <div className="max-w-2xl space-y-6">
        <div>
          <h2 className="text-xl font-bold text-foreground">General Information</h2>
          <p className="text-muted-foreground text-sm mt-1">Define the core parameters of this scenario</p>
        </div>
        <div className="grid grid-cols-2 gap-5">
          <Field label="Scenario Name *" placeholder="e.g. Operation Arctic Falcon" value={form.name} onChange={sf("name")} className="col-span-2" />
          <Sel label="Mission Type" value={form.missionType} onChange={sf("missionType")} options={[
            { label: "Offensive Operation", value: "offensive" }, { label: "Defensive Operation", value: "defensive" },
            { label: "Reconnaissance", value: "recon" }, { label: "Training Exercise", value: "training" },
            { label: "Humanitarian", value: "humanitarian" },
          ]} />
          <Sel label="Classification" value={form.classification} onChange={sf("classification")} options={[
            { label: "UNCLASSIFIED", value: "UNCLASSIFIED" }, { label: "CONFIDENTIAL", value: "CONFIDENTIAL" },
            { label: "SECRET", value: "SECRET" }, { label: "TOP SECRET", value: "TOP SECRET" },
          ]} />
          <Field label="Location / AOR" placeholder="e.g. North Pacific Ocean" value={form.location} onChange={sf("location")} icon={<MapPin size={14} />} />
          <Sel label="Priority" value={form.priority} onChange={sf("priority")} options={[
            { label: "Low", value: "low" }, { label: "Medium", value: "medium" },
            { label: "High", value: "high" }, { label: "Critical", value: "critical" },
          ]} />
          <Field label="Mission Description" placeholder="Describe objectives, scope, and key parameters..." value={form.desc} onChange={sf("desc")} rows={4} className="col-span-2" />
          <Field label="Tags" placeholder="maritime, intercept, exercise" value={form.tags} onChange={sf("tags")} icon={<Tag size={14} />} className="col-span-2" />
        </div>
      </div>
    );

    if (step === 1) return (
      <div className="space-y-6 max-w-3xl">
        <div>
          <h2 className="text-xl font-bold text-foreground">Environment</h2>
          <p className="text-muted-foreground text-sm mt-1">Select operational terrain and atmospheric conditions</p>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {[
            { id: "Ocean", icon: <Ship size={22} />, desc: "Open sea operations" },
            { id: "Land", icon: <Globe size={22} />, desc: "Flat terrain, roads" },
            { id: "Mountain", icon: <TrendingUp size={22} />, desc: "High altitude terrain" },
            { id: "Urban", icon: <Layers size={22} />, desc: "Dense city environment" },
            { id: "Forest", icon: <Activity size={22} />, desc: "Dense vegetation" },
            { id: "Arctic", icon: <Thermometer size={22} />, desc: "Extreme cold weather" },
          ].map(e => (
            <button key={e.id} onClick={() => setEnv(e.id)}
              className={`p-5 rounded-xl border text-left flex flex-col gap-3 transition-all
                ${env === e.id ? "border-primary bg-primary/10" : "border-border bg-card hover:border-primary/30"}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${env === e.id ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"}`}>
                {e.icon}
              </div>
              <div>
                <p className={`text-sm font-semibold ${env === e.id ? "text-primary" : "text-foreground"}`}>{e.id}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{e.desc}</p>
              </div>
              {env === e.id && <Check size={14} className="text-primary" />}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: "Wind Speed (kts)", key: "wind", min: 0, max: 60, icon: <Wind size={14} /> },
            { label: "Visibility (nm)", key: "visibility", min: 0, max: 20, icon: <Eye size={14} /> },
            { label: "Temperature (°C)", key: "temp", min: -30, max: 50, icon: <Thermometer size={14} /> },
            { label: "Sea State (0–9)", key: "sea", min: 0, max: 9, icon: <Cloud size={14} /> },
          ].map(({ label, key, min, max, icon }) => (
            <div key={key} className="p-4 bg-card rounded-xl border border-border flex flex-col gap-2">
              <div className="flex items-center gap-2 text-dim">
                {icon}<span className="text-xs font-medium">{label}</span>
              </div>
              <div className="flex items-center gap-3">
                <input type="range" min={min} max={max} value={wx[key as keyof typeof wx]}
                  onChange={e => setWx(w => ({ ...w, [key]: Number(e.target.value) }))}
                  className="flex-1 accent-[#5CA9C7] cursor-pointer" />
                <span className="text-sm font-bold text-primary w-8 text-right">{wx[key as keyof typeof wx]}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    );

    if (step === 2) return (
      <div className="space-y-5">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-bold text-foreground">Add Entities</h2>
            <p className="text-muted-foreground text-sm mt-1">Select assets to include in this scenario</p>
          </div>
          <Badge variant="info">{selected.length} selected</Badge>
        </div>
        <div className="flex gap-2 flex-wrap">
          {ASSET_CATS.map(c => (
            <button key={c} onClick={() => setCat(c)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all
                ${cat === c ? "bg-primary text-primary-foreground" : "bg-card text-dim border border-border hover:border-primary/40"}`}>
              {c}
            </button>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4">
          {ASSET_POOL.filter(a => a.cat === cat).map(asset => {
            const sel = selected.includes(asset.id);
            return (
              <div key={asset.id}
                className={`p-4 rounded-xl border transition-all ${sel ? "border-primary bg-primary/8" : "border-border bg-card hover:border-primary/30"}`}>
                <div className="flex items-start justify-between mb-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${sel ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"}`}>
                    {asset.icon}
                  </div>
                  {sel && <Check size={14} className="text-primary" />}
                </div>
                <p className="text-sm font-semibold text-foreground mb-0.5">{asset.name}</p>
                <p className="text-xs text-muted-foreground mb-3">{asset.type}</p>
                <button onClick={() => toggleAsset(asset.id)}
                  className={`w-full py-1.5 rounded-lg text-xs font-medium transition-all
                    ${sel ? "bg-primary/20 text-primary" : "bg-muted text-dim hover:bg-primary/10 hover:text-primary"}`}>
                  {sel ? "Remove" : "+ Add"}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );

    if (step === 3) return (
      <div className="max-w-2xl space-y-5">
        <div>
          <h2 className="text-xl font-bold text-foreground">Configure Entities</h2>
          <p className="text-muted-foreground text-sm mt-1">Set operational parameters for each entity</p>
        </div>
        {selected.length === 0 ? (
          <SCard className="p-10 text-center">
            <Package size={32} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-dim text-sm">No assets selected. Go back to add entities.</p>
          </SCard>
        ) : (
          <div className="space-y-3">
            {ASSET_POOL.filter(a => selected.includes(a.id)).map(asset => (
              <div key={asset.id} className="border border-border rounded-xl overflow-hidden">
                <div className="flex items-center gap-3 p-4 bg-card">
                  <span className="text-primary">{asset.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground">{asset.name}</p>
                    <p className="text-xs text-muted-foreground">{asset.type}</p>
                  </div>
                  <ChevronDown size={14} className="text-muted-foreground" />
                </div>
                <div className="p-4 bg-muted border-t border-border grid grid-cols-2 gap-3">
                  <Field label="Latitude" placeholder="0.0000°N" type="number" />
                  <Field label="Longitude" placeholder="0.0000°E" type="number" />
                  <Field label="Heading (°)" placeholder="000" type="number" />
                  <Field label="Speed (kts)" placeholder="0" type="number" />
                  <Sel label="Status" options={[{ label: "Active", value: "active" }, { label: "Standby", value: "standby" }, { label: "Offline", value: "offline" }]} />
                  <Sel label="Allegiance" options={[{ label: "Friendly", value: "friendly" }, { label: "Hostile", value: "hostile" }, { label: "Neutral", value: "neutral" }, { label: "Unknown", value: "unknown" }]} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    );

    if (step === 4) return (
      <div className="space-y-5">
        <div className="flex items-start justify-between">
          <div>
            <h2 className="text-xl font-bold text-foreground">Entity Relationships</h2>
            <p className="text-muted-foreground text-sm mt-1">Define tactical connections between entities</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            {[
              { label: "Attack", color: "#C96A6A" }, { label: "Support", color: "#4FA76A" },
              { label: "Escort", color: "#5CA9C7" }, { label: "Detection", color: "#D4A85E" },
              { label: "Comms", color: "#6E8FB8" },
            ].map(r => (
              <span key={r.label}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-card border border-border">
                <span className="w-2 h-2 rounded-full" style={{ background: r.color }} />
                <span className="text-dim">{r.label}</span>
              </span>
            ))}
          </div>
        </div>
        <div className="relative bg-muted border border-border rounded-xl overflow-hidden" style={{ height: 380 }}>
          <svg width="100%" height="100%">
            <defs>
              <marker id="arr-blue" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#5CA9C7" opacity={0.7} />
              </marker>
              <marker id="arr-green" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#4FA76A" opacity={0.7} />
              </marker>
              <marker id="arr-red" markerWidth="8" markerHeight="8" refX="6" refY="3" orient="auto">
                <path d="M0,0 L0,6 L8,3 z" fill="#C96A6A" opacity={0.7} />
              </marker>
            </defs>
            {/* Connections */}
            <line x1="210" y1="160" x2="440" y2="110" stroke="#5CA9C7" strokeWidth={1.5} strokeOpacity={0.5} markerEnd="url(#arr-blue)" strokeDasharray="6 3" />
            <line x1="210" y1="160" x2="340" y2="290" stroke="#4FA76A" strokeWidth={1.5} strokeOpacity={0.5} markerEnd="url(#arr-green)" />
            <line x1="440" y1="110" x2="620" y2="210" stroke="#C96A6A" strokeWidth={1.5} strokeOpacity={0.5} markerEnd="url(#arr-red)" strokeDasharray="6 3" />
            <line x1="340" y1="290" x2="620" y2="210" stroke="#6E8FB8" strokeWidth={1.5} strokeOpacity={0.5} markerEnd="url(#arr-blue)" />
            <line x1="210" y1="160" x2="130" y2="270" stroke="#D4A85E" strokeWidth={1.5} strokeOpacity={0.5} markerEnd="url(#arr-green)" strokeDasharray="4 2" />
            {/* Nodes */}
            {[
              { x: 210, y: 160, label: "Gerald R. Ford", sub: "Carrier", col: "#5CA9C7" },
              { x: 440, y: 110, label: "F/A-18 Hornet", sub: "Fighter", col: "#6E8FB8" },
              { x: 340, y: 290, label: "Virginia SSN", sub: "Submarine", col: "#4FA76A" },
              { x: 620, y: 210, label: "AN/TPY-2", sub: "Radar", col: "#D4A85E" },
              { x: 130, y: 270, label: "Arleigh Burke", sub: "Destroyer", col: "#5CA9C7" },
            ].map((nd, i) => (
              <g key={i} className="cursor-pointer">
                <circle cx={nd.x} cy={nd.y} r={34} fill="#252C34" stroke={nd.col} strokeWidth={1.5} strokeOpacity={0.6} />
                <circle cx={nd.x} cy={nd.y} r={28} fill="#1D232A" />
                <circle cx={nd.x} cy={nd.y} r={5} fill={nd.col} opacity={0.8} />
                <text x={nd.x} y={nd.y + 50} textAnchor="middle" fill="#E8EDF2" fontSize={11} fontWeight="500">{nd.label}</text>
                <text x={nd.x} y={nd.y + 64} textAnchor="middle" fill="#7B8794" fontSize={10}>{nd.sub}</text>
              </g>
            ))}
          </svg>
          <div className="absolute bottom-3 right-3 flex gap-1.5">
            {[<ZoomIn size={14} />, <ZoomOut size={14} />, <RotateCcw size={14} />].map((ic, i) => (
              <button key={i}
                className="w-8 h-8 bg-card border border-border rounded-lg flex items-center justify-center text-dim hover:text-foreground transition-colors">
                {ic}
              </button>
            ))}
          </div>
        </div>
      </div>
    );

    if (step === 5) return (
      <div className="space-y-5">
        <div>
          <h2 className="text-xl font-bold text-foreground">Mission Timeline</h2>
          <p className="text-muted-foreground text-sm mt-1">Define phases, events, and triggers</p>
        </div>
        <div className="bg-muted border border-border rounded-xl p-5 overflow-x-auto">
          <div className="min-w-[760px]">
            <div className="flex mb-4 ml-32 gap-0">
              {Array.from({ length: 12 }, (_, i) => (
                <div key={i} className="flex-1 text-[10px] text-muted-foreground border-l border-border pl-1 font-mono">T+{i}h</div>
              ))}
            </div>
            {[
              { label: "Ingress", color: "#5CA9C7", start: 0, dur: 2, opacity: 0.85 },
              { label: "ISR Phase", color: "#6E8FB8", start: 1.5, dur: 3, opacity: 0.85 },
              { label: "Strike Window", color: "#C96A6A", start: 4, dur: 1.5, opacity: 0.9 },
              { label: "Support Ops", color: "#4FA76A", start: 1, dur: 6.5, opacity: 0.7 },
              { label: "Egress", color: "#5CA9C7", start: 5.5, dur: 2, opacity: 0.85 },
            ].map((ph, i) => (
              <div key={i} className="flex items-center gap-3 mb-2.5">
                <span className="w-28 text-xs text-dim text-right shrink-0 font-medium">{ph.label}</span>
                <div className="flex-1 relative h-7 bg-card rounded-md border border-border">
                  <div
                    className="absolute h-full rounded-md flex items-center px-2.5 text-xs font-semibold text-white cursor-pointer hover:brightness-110 transition-all"
                    style={{ left: `${(ph.start / 12) * 100}%`, width: `${(ph.dur / 12) * 100}%`, background: ph.color, opacity: ph.opacity }}>
                    {ph.dur >= 1.2 ? ph.label : ""}
                  </div>
                </div>
              </div>
            ))}
            <div className="flex items-center gap-3 mt-5 pt-4 border-t border-border">
              <span className="w-28 text-xs text-muted-foreground text-right shrink-0">Events</span>
              <div className="flex-1 relative h-8">
                {[{ t: 0.5, label: "Launch", col: "#5CA9C7" }, { t: 4, label: "Strike", col: "#C96A6A" }, { t: 5.5, label: "RTB", col: "#4FA76A" }, { t: 7.5, label: "Land", col: "#D4A85E" }].map((ev, i) => (
                  <div key={i} className="absolute top-0 flex flex-col items-center gap-1 cursor-pointer hover:scale-105 transition-transform"
                    style={{ left: `${(ev.t / 12) * 100}%` }}>
                    <div className="w-3 h-3 rounded-full border-2 border-muted" style={{ background: ev.col }} />
                    <span className="text-[10px] font-medium whitespace-nowrap" style={{ color: ev.col }}>{ev.label}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );

    if (step === 6) return (
      <div className="max-w-3xl space-y-5">
        <div>
          <h2 className="text-xl font-bold text-foreground">Review Scenario</h2>
          <p className="text-muted-foreground text-sm mt-1">Verify all parameters before generation</p>
        </div>
        <div className="space-y-2">
          {[
            { ok: form.name.trim().length > 0, msg: "Scenario name defined", warn: false },
            { ok: true, msg: `Environment: ${env}`, warn: false },
            { ok: selected.length > 0, msg: selected.length > 0 ? `${selected.length} entities configured` : "No entities selected", warn: false },
            { ok: true, msg: "Timeline: 5 phases, 4 events", warn: false },
            { ok: selected.length >= 2, msg: selected.length >= 2 ? "Entity relationships mapped" : "Fewer than 2 entities — relationships incomplete", warn: selected.length < 2 },
          ].map((v, i) => (
            <div key={i} className={`flex items-center gap-3 p-3 rounded-xl border transition-colors ${v.ok ? "border-success/25 bg-success/5" : "border-destructive/25 bg-destructive/5"}`}>
              {v.ok
                ? <Check size={14} className="text-success shrink-0" />
                : <AlertTriangle size={14} className="text-destructive shrink-0" />}
              <span className={`text-sm ${v.ok ? "text-foreground" : "text-destructive"}`}>{v.msg}</span>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-4">
          <SCard className="p-4">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Mission Summary</h4>
            <div className="space-y-2 text-sm">
              {[
                { l: "Name", v: form.name || "Untitled Scenario", badge: false },
                { l: "Type", v: form.missionType, badge: true, bv: "info" },
                { l: "Environment", v: env, badge: false },
                { l: "Priority", v: form.priority, badge: true, bv: form.priority === "critical" ? "danger" as const : form.priority === "high" ? "warning" as const : "default" as const },
                { l: "Classification", v: form.classification, badge: true, bv: "danger" as const },
              ].map(row => (
                <div key={row.l} className="flex justify-between items-center gap-2">
                  <span className="text-muted-foreground text-xs">{row.l}</span>
                  {row.badge ? <Badge variant={row.bv as "info" | "danger" | "warning" | "default"}>{row.v}</Badge> : <span className="text-foreground text-xs font-medium">{row.v}</span>}
                </div>
              ))}
            </div>
          </SCard>
          <SCard className="p-4">
            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Entity Summary</h4>
            {selected.length === 0
              ? <p className="text-xs text-muted-foreground">No entities selected</p>
              : Object.entries(ASSET_POOL.filter(a => selected.includes(a.id)).reduce((acc, a) => ({ ...acc, [a.cat]: (acc[a.cat] || 0) + 1 }), {} as Record<string, number>)).map(([c, n]) => (
                <div key={c} className="flex justify-between items-center py-1.5 border-b border-border last:border-0">
                  <span className="text-xs text-dim">{c}</span>
                  <span className="text-xs font-semibold text-primary">{n}</span>
                </div>
              ))
            }
          </SCard>
        </div>
      </div>
    );

    // Step 7: Generate
    return (
      <div className="max-w-xl mx-auto flex flex-col items-center text-center gap-8 py-8">
        <motion.div
          className="w-24 h-24 rounded-2xl bg-primary/15 border border-primary/30 flex items-center justify-center"
          animate={{ scale: [1, 1.06, 1], boxShadow: ["0 0 0 0 rgba(92,169,199,0)", "0 0 0 16px rgba(92,169,199,0.08)", "0 0 0 0 rgba(92,169,199,0)"] }}
          transition={{ duration: 2.5, repeat: Infinity }}>
          <Target size={40} className="text-primary" />
        </motion.div>
        <div>
          <h2 className="text-2xl font-bold text-foreground">Ready to Generate</h2>
          <p className="text-muted-foreground text-sm mt-2 max-w-sm">All parameters are configured. This will compile a fully deployable scenario package.</p>
        </div>
        <div className="grid grid-cols-3 gap-4 w-full">
          {[
            { l: "Entities", v: selected.length },
            { l: "Timeline Events", v: 4 },
            { l: "Relationships", v: Math.max(0, selected.length * 2 - 2) },
          ].map(m => (
            <SCard key={m.l} className="p-4">
              <p className="text-3xl font-bold text-primary">{m.v}</p>
              <p className="text-xs text-muted-foreground mt-1">{m.l}</p>
            </SCard>
          ))}
        </div>
        <div className="flex gap-3">
          <Btn variant="secondary" icon={<Save size={14} />}>Save Draft</Btn>
          <Btn size="lg" icon={<Play size={14} />}
            onClick={() => toast.success(`Scenario "${form.name || "Untitled"}" generated successfully!`)}>
            Generate Scenario
          </Btn>
          <Btn variant="secondary" icon={<Download size={14} />}>Export JSON</Btn>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Stepper */}
      <div className="bg-muted border-b border-border px-6 py-4 shrink-0">
        <div className="flex items-center">
          {STEPS.map((s, i) => (
            <div key={s} className="flex items-center flex-1 min-w-0">
              <button onClick={() => setStep(i)} className="flex items-center gap-2 group shrink-0">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-all shrink-0
                  ${i === step ? "bg-primary text-primary-foreground" : i < step ? "bg-primary/25 text-primary border border-primary/40" : "bg-card text-muted-foreground border border-border"}`}>
                  {i < step ? <Check size={12} /> : i + 1}
                </div>
                <span className={`text-xs font-medium hidden lg:block whitespace-nowrap
                  ${i === step ? "text-primary" : i < step ? "text-dim" : "text-muted-foreground"}`}>{s}</span>
              </button>
              {i < STEPS.length - 1 && (
                <div className={`flex-1 h-px mx-3 transition-all ${i < step ? "bg-primary/40" : "bg-border"}`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <AnimatePresence mode="wait">
          <motion.div key={step}
            initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}
            transition={{ duration: 0.18 }}>
            {stepContent()}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Footer actions */}
      <div className="shrink-0 border-t border-border bg-muted px-6 py-4 flex items-center justify-between">
        <div className="flex gap-2">
          <Btn variant="ghost" onClick={onCancel} icon={<X size={14} />}>Cancel</Btn>
          <Btn variant="secondary" icon={<Save size={14} />}>Save Draft</Btn>
        </div>
        <div className="flex gap-2">
          {step > 0 && <Btn variant="secondary" onClick={() => setStep(s => s - 1)} icon={<ChevronLeft size={14} />}>Previous</Btn>}
          <Btn onClick={() => { if (step < STEPS.length - 1) setStep(s => s + 1); else toast.success("Scenario generated!"); }}
            icon={step === STEPS.length - 1 ? <Play size={14} /> : <ChevronRight size={14} />}>
            {step === STEPS.length - 1 ? "Generate" : "Continue"}
          </Btn>
        </div>
      </div>
    </div>
  );
}

// ─── Scenario Library ─────────────────────────────────────────────────────────

const LIB_SCENARIOS = [
  { id: 1, name: "Operation Neptune Strike", type: "Maritime", status: "active", entities: 24, ago: "2h", owner: "CDR Smith", priority: "High" },
  { id: 2, name: "Arctic Falcon Intercept", type: "Aviation", status: "draft", entities: 12, ago: "1d", owner: "LT Johnson", priority: "Critical" },
  { id: 3, name: "Desert Shield Defense", type: "Ground", status: "complete", entities: 38, ago: "3d", owner: "MAJ Torres", priority: "Medium" },
  { id: 4, name: "Orbital Surveillance Net", type: "Space", status: "review", entities: 8, ago: "5d", owner: "CDR Kim", priority: "Low" },
  { id: 5, name: "Baltic Sea Patrol", type: "Maritime", status: "active", entities: 16, ago: "6h", owner: "LT Petrov", priority: "Medium" },
  { id: 6, name: "Sahel Reconnaissance", type: "Aviation", status: "complete", entities: 6, ago: "2d", owner: "CPT Diallo", priority: "Low" },
  { id: 7, name: "Mountain Fortress Defense", type: "Ground", status: "draft", entities: 44, ago: "4d", owner: "MAJ Chen", priority: "High" },
];

// PDF preview types
type LibScenario = typeof LIB_SCENARIOS[number];

function PdfPreviewDrawer({ scenario, onClose }: { scenario: LibScenario; onClose: () => void }) {
  const typeIcon = scenario.type === "Maritime" ? <Ship size={16} /> : scenario.type === "Aviation" ? <Plane size={16} /> : scenario.type === "Space" ? <Satellite size={16} /> : <Shield size={16} />;

  const sampleEntities = ASSET_POOL.slice(0, Math.min(scenario.entities, 5));
  const phases = [
    { label: "Phase 1 — Ingress", duration: "T+0h to T+2h", color: "#5CA9C7" },
    { label: "Phase 2 — ISR Sweep", duration: "T+1h30 to T+4h30", color: "#6E8FB8" },
    { label: "Phase 3 — Strike Window", duration: "T+4h to T+5h30", color: "#C96A6A" },
    { label: "Phase 4 — Egress & RTB", duration: "T+5h30 to T+7h30", color: "#4FA76A" },
  ];

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex"
        onClick={onClose}
      >
        {/* Backdrop */}
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />

        {/* Drawer */}
        <motion.div
          initial={{ x: "100%" }}
          animate={{ x: 0 }}
          exit={{ x: "100%" }}
          transition={{ type: "spring", damping: 28, stiffness: 300 }}
          onClick={e => e.stopPropagation()}
          className="absolute right-0 top-0 h-full w-[680px] bg-muted border-l border-border flex flex-col overflow-hidden"
        >
          {/* Drawer header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0 bg-muted">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-destructive/20 rounded-lg flex items-center justify-center">
                <FileText size={16} className="text-destructive" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">PDF Preview</p>
                <p className="text-xs text-muted-foreground">{scenario.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Btn variant="secondary" size="sm" icon={<Download size={13} />}
                onClick={() => toast.success("PDF exported successfully")}>
                Export PDF
              </Btn>
              <button onClick={onClose}
                className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                <X size={16} />
              </button>
            </div>
          </div>

          {/* PDF document area */}
          <div className="flex-1 overflow-y-auto p-6 bg-background">
            {/* Paper */}
            <div className="bg-white rounded-xl overflow-hidden shadow-2xl shadow-black/40 mx-auto max-w-[580px]">

              {/* Classification banner */}
              <div className="bg-destructive px-6 py-2 text-center">
                <p className="text-white text-xs font-bold tracking-widest uppercase">
                  {scenario.priority === "Critical" ? "TOP SECRET // SCI" : "SECRET // REL TO FVEY"}
                </p>
              </div>

              {/* Document header */}
              <div className="px-8 pt-8 pb-6 border-b border-gray-200">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-2 text-primary">
                    {typeIcon}
                    <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider">{scenario.type} Operation</span>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-400">Document Ref:</p>
                    <p className="text-xs font-mono text-gray-600">SB-{String(scenario.id).padStart(4, "0")}-{new Date().getFullYear()}</p>
                  </div>
                </div>
                <h1 className="text-2xl font-bold text-gray-900 mb-1">{scenario.name}</h1>
                <p className="text-sm text-gray-500">Mission Planning Document · Scenario Builder v4.2</p>
                <div className="flex gap-3 mt-4 flex-wrap">
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold
                    ${scenario.status === "active" ? "bg-green-100 text-green-700" : scenario.status === "complete" ? "bg-blue-100 text-blue-700" : scenario.status === "review" ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-600"}`}>
                    {scenario.status.toUpperCase()}
                  </span>
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-semibold
                    ${scenario.priority === "Critical" ? "bg-red-100 text-red-700" : scenario.priority === "High" ? "bg-orange-100 text-orange-700" : "bg-gray-100 text-gray-600"}`}>
                    PRIORITY: {scenario.priority.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Mission Parameters */}
              <div className="px-8 py-6 border-b border-gray-200">
                <h2 className="text-sm font-bold text-gray-800 uppercase tracking-wider mb-4">1. Mission Parameters</h2>
                <div className="grid grid-cols-2 gap-x-8 gap-y-3">
                  {[
                    { label: "Operation Name", value: scenario.name },
                    { label: "Domain", value: scenario.type },
                    { label: "Commanding Officer", value: scenario.owner },
                    { label: "Priority Level", value: scenario.priority },
                    { label: "Last Modified", value: `${scenario.ago} ago` },
                    { label: "Total Entities", value: String(scenario.entities) },
                    { label: "Area of Operations", value: "North Pacific Ocean" },
                    { label: "Mission Duration", value: "7.5 hours" },
                  ].map(row => (
                    <div key={row.label}>
                      <p className="text-[10px] font-semibold text-gray-400 uppercase tracking-wider">{row.label}</p>
                      <p className="text-sm text-gray-800 mt-0.5 font-medium">{row.value}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Mission Overview */}
              <div className="px-8 py-6 border-b border-gray-200">
                <h2 className="text-sm font-bold text-gray-800 uppercase tracking-wider mb-3">2. Mission Overview</h2>
                <p className="text-sm text-gray-600 leading-relaxed">
                  This scenario establishes a multi-domain operational framework for {scenario.name}. The mission
                  involves coordinated {scenario.type.toLowerCase()} assets operating within the designated Area of
                  Responsibility (AOR). All entities are configured per standing operational doctrine and ROE in
                  effect as of the scenario generation date.
                </p>
                <p className="text-sm text-gray-600 leading-relaxed mt-2">
                  Intelligence assessments indicate {scenario.priority.toLowerCase()} threat environment.
                  Commander&apos;s intent is to achieve mission objectives while minimizing collateral effects and
                  maintaining operational security throughout all phases.
                </p>
              </div>

              {/* Entity Roster */}
              <div className="px-8 py-6 border-b border-gray-200">
                <h2 className="text-sm font-bold text-gray-800 uppercase tracking-wider mb-4">3. Entity Roster ({scenario.entities} Total)</h2>
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left text-[10px] text-gray-400 uppercase tracking-wider pb-2 pr-4">Asset</th>
                      <th className="text-left text-[10px] text-gray-400 uppercase tracking-wider pb-2 pr-4">Type</th>
                      <th className="text-left text-[10px] text-gray-400 uppercase tracking-wider pb-2 pr-4">Category</th>
                      <th className="text-left text-[10px] text-gray-400 uppercase tracking-wider pb-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sampleEntities.map((e, i) => (
                      <tr key={e.id} className={i < sampleEntities.length - 1 ? "border-b border-gray-100" : ""}>
                        <td className="py-2 pr-4 font-medium text-gray-800 text-xs">{e.name}</td>
                        <td className="py-2 pr-4 text-gray-500 text-xs">{e.type}</td>
                        <td className="py-2 pr-4 text-gray-500 text-xs">{e.cat}</td>
                        <td className="py-2">
                          <span className="inline-flex px-1.5 py-0.5 bg-green-100 text-green-700 text-[10px] font-semibold rounded">ACTIVE</span>
                        </td>
                      </tr>
                    ))}
                    {scenario.entities > 5 && (
                      <tr>
                        <td colSpan={4} className="pt-2 text-xs text-gray-400 italic">
                          + {scenario.entities - 5} additional entities not shown in preview
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Timeline */}
              <div className="px-8 py-6 border-b border-gray-200">
                <h2 className="text-sm font-bold text-gray-800 uppercase tracking-wider mb-4">4. Mission Timeline</h2>
                <div className="space-y-2.5">
                  {phases.map((ph, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full shrink-0" style={{ background: ph.color }} />
                      <div className="flex-1 flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-800">{ph.label}</span>
                        <span className="text-xs text-gray-400 font-mono">{ph.duration}</span>
                      </div>
                    </div>
                  ))}
                </div>
                {/* Visual bar */}
                <div className="mt-4 flex rounded-full overflow-hidden h-3">
                  {[["#5CA9C7", "27%"], ["#6E8FB8", "40%"], ["#C96A6A", "20%"], ["#4FA76A", "27%"]].map(([col, w], i) => (
                    <div key={i} className="h-full" style={{ background: col, width: w, opacity: 0.8 }} />
                  ))}
                </div>
                <div className="flex justify-between text-[10px] text-gray-400 mt-1">
                  <span>T+0h</span><span>T+3h</span><span>T+5h</span><span>T+7.5h</span>
                </div>
              </div>

              {/* Approval block */}
              <div className="px-8 py-6">
                <h2 className="text-sm font-bold text-gray-800 uppercase tracking-wider mb-4">5. Approval &amp; Authorization</h2>
                <div className="grid grid-cols-3 gap-4">
                  {["Prepared By", "Reviewed By", "Authorized By"].map(role => (
                    <div key={role} className="border border-gray-200 rounded-lg p-3">
                      <p className="text-[10px] text-gray-400 uppercase tracking-wider mb-4">{role}</p>
                      <div className="border-b border-gray-300 mb-1.5" />
                      <p className="text-[10px] text-gray-400">Signature / Date</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Classification footer */}
              <div className="bg-destructive px-6 py-2 text-center">
                <p className="text-white text-xs font-bold tracking-widest uppercase">
                  {scenario.priority === "Critical" ? "TOP SECRET // SCI" : "SECRET // REL TO FVEY"}
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function ScenarioLibrary({ onNav }: { onNav: (s: AppScreen) => void }) {
  const [view, setView] = useState<"table" | "grid">("table");
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [pdfScenario, setPdfScenario] = useState<LibScenario | null>(null);

  const list = LIB_SCENARIOS.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) &&
    (filterStatus === "all" || s.status === filterStatus)
  );

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      {pdfScenario && <PdfPreviewDrawer scenario={pdfScenario} onClose={() => setPdfScenario(null)} />}

      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Scenario Library</h2>
          <p className="text-muted-foreground text-sm mt-0.5">{LIB_SCENARIOS.length} scenarios · {LIB_SCENARIOS.filter(s => s.status === "active").length} active</p>
        </div>
        <Btn onClick={() => onNav("create-scenario")} icon={<Plus size={14} />}>New Scenario</Btn>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search scenarios..."
            className="w-full h-10 bg-card border border-border rounded-lg pl-8 pr-4 text-sm text-foreground placeholder-muted-foreground outline-none focus:border-primary transition-colors" />
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="h-10 bg-card border border-border rounded-lg px-3 text-sm text-foreground outline-none focus:border-primary">
          {["all", "active", "draft", "complete", "review"].map(v => (
            <option key={v} value={v}>{v === "all" ? "All Status" : v.charAt(0).toUpperCase() + v.slice(1)}</option>
          ))}
        </select>
        <div className="flex border border-border rounded-lg overflow-hidden">
          <button onClick={() => setView("table")}
            className={`px-3 py-2.5 transition-colors ${view === "table" ? "bg-primary/20 text-primary" : "bg-card text-muted-foreground hover:text-foreground"}`}>
            <List size={15} />
          </button>
          <button onClick={() => setView("grid")}
            className={`px-3 py-2.5 transition-colors ${view === "grid" ? "bg-primary/20 text-primary" : "bg-card text-muted-foreground hover:text-foreground"}`}>
            <Grid size={15} />
          </button>
        </div>
      </div>

      {view === "table" ? (
        <SCard className="overflow-hidden p-0">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                {["Scenario", "Type", "Status", "Priority", "Entities", "Owner", "Modified", "Actions"].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {list.map((s, i) => (
                <tr key={s.id}
                  className={`hover:bg-muted transition-colors ${i < list.length - 1 ? "border-b border-border" : ""}`}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-lg bg-muted border border-border flex items-center justify-center text-primary shrink-0">
                        {domainIcon(s.type)}
                      </div>
                      <span className="text-sm font-medium text-foreground">{s.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-xs text-dim">{s.type}</td>
                  <td className="px-4 py-3">
                    <Badge variant={s.status === "active" ? "success" : s.status === "complete" ? "info" : s.status === "review" ? "warning" : "default"}>{s.status}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant={s.priority === "Critical" ? "danger" : s.priority === "High" ? "warning" : "default"}>{s.priority}</Badge>
                  </td>
                  <td className="px-4 py-3 text-xs text-dim">{s.entities}</td>
                  <td className="px-4 py-3 text-xs text-dim">{s.owner}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{s.ago} ago</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button title="View"
                        className="w-7 h-7 rounded-lg hover:bg-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                        <Eye size={13} />
                      </button>
                      {/* PDF preview button */}
                      <button title="PDF Preview" onClick={() => setPdfScenario(s)}
                        className="w-7 h-7 rounded-lg hover:bg-destructive/15 flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors">
                        <FileText size={13} />
                      </button>
                      <button title="Edit"
                        className="w-7 h-7 rounded-lg hover:bg-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                        <Edit2 size={13} />
                      </button>
                      <button title="Duplicate"
                        className="w-7 h-7 rounded-lg hover:bg-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                        <Copy size={13} />
                      </button>
                      <button title="Delete"
                        className="w-7 h-7 rounded-lg hover:bg-destructive/15 flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </SCard>
      ) : (
        <div className="grid grid-cols-3 gap-4">
          {list.map(s => (
            <SCard key={s.id} className="p-4 hover:border-primary/40">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-muted border border-border flex items-center justify-center text-primary">
                  {s.type === "Maritime" ? <Ship size={18} /> : s.type === "Aviation" ? <Plane size={18} /> : s.type === "Space" ? <Satellite size={18} /> : <Shield size={18} />}
                </div>
                <Badge variant={s.status === "active" ? "success" : s.status === "complete" ? "info" : s.status === "review" ? "warning" : "default"}>{s.status}</Badge>
              </div>
              <p className="font-semibold text-foreground text-sm mb-1">{s.name}</p>
              <p className="text-xs text-muted-foreground mb-3">{s.type} · {s.entities} entities</p>
              <div className="flex items-center justify-between border-t border-border pt-3">
                <span className="text-xs text-muted-foreground">{s.owner} · {s.ago} ago</span>
                <div className="flex gap-1">
                  <button title="View"
                    className="w-6 h-6 rounded-md hover:bg-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                    <Eye size={12} />
                  </button>
                  <button title="PDF Preview" onClick={() => setPdfScenario(s)}
                    className="w-6 h-6 rounded-md hover:bg-destructive/15 flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors">
                    <FileText size={12} />
                  </button>
                  <button title="Edit"
                    className="w-6 h-6 rounded-md hover:bg-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                    <Edit2 size={12} />
                  </button>
                </div>
              </div>
            </SCard>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Asset Library ────────────────────────────────────────────────────────────

const ALL_ASSETS = [
  ...ASSET_POOL,
  { id: 13, name: "P-8A Poseidon", cat: "Aircraft", type: "Maritime Patrol Aircraft", icon: <Plane size={20} /> },
  { id: 14, name: "Los Angeles-class SSN", cat: "Submarine", type: "Fast Attack Submarine", icon: <Anchor size={20} /> },
  { id: 15, name: "BGM-109 Tomahawk", cat: "Missiles", type: "Land-Attack Cruise Missile", icon: <Zap size={20} /> },
  { id: 16, name: "WGS Satellite", cat: "Satellite", type: "Wideband Comms Satellite", icon: <Satellite size={20} /> },
];

function AssetLibrary() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const cats = ["All", ...Array.from(new Set(ALL_ASSETS.map(a => a.cat)))];
  const list = ALL_ASSETS.filter(a =>
    (category === "All" || a.cat === category) &&
    a.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Asset Library</h2>
          <p className="text-muted-foreground text-sm mt-0.5">{ALL_ASSETS.length} assets across {cats.length - 1} categories</p>
        </div>
        <div className="flex gap-2">
          <Btn variant="secondary" icon={<Upload size={14} />}>Import</Btn>
          <Btn icon={<Plus size={14} />}>Add Asset</Btn>
        </div>
      </div>

      <div className="flex gap-3 flex-wrap items-center">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search assets..."
            className="w-56 h-10 bg-card border border-border rounded-lg pl-8 pr-4 text-sm text-foreground placeholder-muted-foreground outline-none focus:border-primary" />
        </div>
        {cats.map(c => (
          <button key={c} onClick={() => setCategory(c)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all
              ${category === c ? "bg-primary text-primary-foreground" : "bg-card text-dim border border-border hover:border-primary/30"}`}>
            {c}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-4 gap-4">
        {list.map(asset => (
          <SCard key={asset.id} className="p-4 cursor-pointer hover:border-primary/40 group">
            <div className="w-full aspect-video bg-muted rounded-xl border border-border mb-3 flex items-center justify-center text-primary group-hover:border-primary/30 transition-colors">
              <span className="scale-[2]">{asset.icon}</span>
            </div>
            <p className="font-semibold text-foreground text-sm mb-0.5 truncate">{asset.name}</p>
            <p className="text-xs text-muted-foreground mb-2 truncate">{asset.type}</p>
            <div className="flex items-center justify-between">
              <Badge>{asset.cat}</Badge>
              <button className="text-xs text-primary hover:underline">Preview</button>
            </div>
          </SCard>
        ))}
      </div>
    </div>
  );
}

// ─── Reports ──────────────────────────────────────────────────────────────────

const barData = [
  { m: "Jan", n: 12 }, { m: "Feb", n: 18 }, { m: "Mar", n: 14 },
  { m: "Apr", n: 24 }, { m: "May", n: 21 }, { m: "Jun", n: 32 }, { m: "Jul", n: 28 },
];

function Reports() {
  const cc = useChartColors();
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Reports & Analytics</h2>
          <p className="text-muted-foreground text-sm mt-0.5">Mission performance and operational metrics</p>
        </div>
        <div className="flex gap-2">
          <Btn variant="secondary" icon={<Download size={14} />}>Export PDF</Btn>
          <Btn variant="secondary" icon={<Download size={14} />}>Export CSV</Btn>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Total Missions", value: "247", icon: <FileText size={18} />, color: "#5CA9C7" },
          { label: "Avg Duration", value: "4.2h", icon: <Clock size={18} />, color: "#6E8FB8" },
          { label: "Completion Rate", value: "94.2%", icon: <Activity size={18} />, color: "#4FA76A" },
          { label: "Asset Utilization", value: "78%", icon: <Package size={18} />, color: "#D4A85E" },
        ].map(m => (
          <SCard key={m.label} className="p-4 flex flex-col gap-3">
            <span style={{ color: m.color }}>{m.icon}</span>
            <p className="text-2xl font-bold text-foreground">{m.value}</p>
            <p className="text-xs text-muted-foreground">{m.label}</p>
          </SCard>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <SCard className="p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Missions by Month</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={barData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
              <CartesianGrid key="grid" strokeDasharray="3 3" stroke={cc.grid} />
              <XAxis key="x" dataKey="m" stroke={cc.axis} tick={{ fill: cc.axis, fontSize: 11 }} />
              <YAxis key="y" stroke={cc.axis} tick={{ fill: cc.axis, fontSize: 11 }} />
              <Tooltip key="tip" contentStyle={{ ...cc.tooltip, borderRadius: 8 }} />
              <Bar key="bar" dataKey="n" fill="#5CA9C7" radius={[4, 4, 0, 0]} name="Missions" />
            </BarChart>
          </ResponsiveContainer>
        </SCard>

        <SCard className="p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Asset Usage by Domain</h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" outerRadius={80} dataKey="value"
                label={({ name, value }) => `${name} ${value}%`} labelLine={{ stroke: cc.grid }}>
                {pieData.map((e) => <Cell key={e.name} fill={e.color} />)}
              </Pie>
              <Tooltip key="tip" contentStyle={{ ...cc.tooltip, borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
        </SCard>
      </div>

      <SCard className="p-5">
        <h3 className="text-sm font-semibold text-foreground mb-4">Activity Trend (7 months)</h3>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={areaData} margin={{ top: 4, right: 4, bottom: 0, left: -20 }}>
            <CartesianGrid key="grid" strokeDasharray="3 3" stroke={cc.grid} />
            <XAxis key="x" dataKey="m" stroke={cc.axis} tick={{ fill: cc.axis, fontSize: 11 }} />
            <YAxis key="y" stroke={cc.axis} tick={{ fill: cc.axis, fontSize: 11 }} />
            <Tooltip key="tip" contentStyle={{ ...cc.tooltip, borderRadius: 8 }} />
            <Area key="sc" type="monotone" dataKey="sc" stroke="#5CA9C7" fill="#5CA9C7" fillOpacity={0.15} strokeWidth={2} name="Scenarios" />
          </AreaChart>
        </ResponsiveContainer>
      </SCard>
    </div>
  );
}

// ─── Notifications ────────────────────────────────────────────────────────────

const NOTIFS = [
  { id: 1, title: "Arctic Falcon parameters updated", body: "LT Johnson updated mission parameters and re-submitted.", time: "5m", type: "info", read: false },
  { id: 2, title: "3 new maritime assets imported", body: "Asset library updated with new surface combatant assets.", time: "22m", type: "success", read: false },
  { id: 3, title: "Validation warning — Desert Shield", body: "Entity positions incomplete for 4 ground units.", time: "1h", type: "warning", read: false },
  { id: 4, title: "Neptune Strike package ready", body: "Scenario compiled. Download available.", time: "2h", type: "success", read: true },
  { id: 5, title: "CMO review request", body: "Orbital Surveillance Net requires CO sign-off before deployment.", time: "3h", type: "info", read: true },
  { id: 6, title: "Storage approaching capacity", body: "Usage at 78%. Archive completed scenarios to free space.", time: "4h", type: "warning", read: true },
];

function NotificationsPage() {
  const [tab, setTab] = useState("all");
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Notifications</h2>
          <p className="text-muted-foreground text-sm mt-0.5">{NOTIFS.filter(n => !n.read).length} unread messages</p>
        </div>
        <Btn variant="ghost" size="sm">Mark all as read</Btn>
      </div>
      <div className="flex gap-1">
        {["all", "unread", "mentions"].map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-medium capitalize transition-colors
              ${tab === t ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-card"}`}>
            {t}
          </button>
        ))}
      </div>
      <div className="space-y-2">
        {NOTIFS.map(n => (
          <div key={n.id}
            className={`flex gap-4 p-4 rounded-xl border transition-colors cursor-pointer
              ${n.read ? "border-border bg-card hover:bg-card-foreground/5" : "border-primary/20 bg-primary/5 hover:bg-primary/8"}`}>
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0
              ${n.type === "success" ? "bg-success/20 text-success" : n.type === "warning" ? "bg-warning/20 text-warning" : "bg-primary/20 text-primary"}`}>
              {n.type === "success" ? <Check size={16} /> : n.type === "warning" ? <AlertTriangle size={16} /> : <Info size={16} />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <p className={`text-sm font-semibold ${n.read ? "text-dim" : "text-foreground"}`}>{n.title}</p>
                {!n.read && <div className="w-2 h-2 rounded-full bg-primary shrink-0" />}
              </div>
              <p className="text-xs text-muted-foreground leading-snug">{n.body}</p>
            </div>
            <span className="text-xs text-muted-foreground shrink-0">{n.time} ago</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Settings ─────────────────────────────────────────────────────────────────

function SettingsPage() {
  const [tab, setTab] = useState("profile");
  const { theme, toggle } = useTheme();
  const tabs = ["Profile", "Security", "Notifications", "Theme", "Storage", "API", "Preferences"];

  return (
    <div className="flex-1 flex overflow-hidden">
      <aside className="w-48 border-r border-border py-4 px-2.5 shrink-0">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t.toLowerCase())}
            className={`w-full flex items-center px-3 py-2.5 rounded-xl text-sm font-medium text-left transition-all mb-0.5
              ${tab === t.toLowerCase() ? "bg-primary/12 text-primary" : "text-dim hover:text-foreground hover:bg-card"}`}>
            {t}
          </button>
        ))}
      </aside>
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-lg space-y-6">
          {tab === "profile" && (
            <>
              <div>
                <h3 className="text-lg font-bold text-foreground">Profile Settings</h3>
                <p className="text-muted-foreground text-sm mt-0.5">Update your personal and organizational info</p>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-primary/15 border-2 border-primary/40 flex items-center justify-center text-primary text-xl font-bold">OC</div>
                <Btn variant="secondary" size="sm">Change Avatar</Btn>
              </div>
              <div className="space-y-4">
                <Field label="Full Name" placeholder="Rank First Last" value="Operator Cmdr." />
                <Field label="Email" placeholder="user@domain.mil" value="operator@mil.gov" type="email" />
                <Field label="Organization" placeholder="Command Unit" value="NAVSPECWARCOM" />
                <Field label="Position" placeholder="Title / Role" value="Operations Commander" />
                <Btn icon={<Save size={14} />}>Save Changes</Btn>
              </div>
            </>
          )}
          {tab === "security" && (
            <>
              <div>
                <h3 className="text-lg font-bold text-foreground">Security Settings</h3>
                <p className="text-muted-foreground text-sm mt-0.5">Manage your credentials and access controls</p>
              </div>
              <div className="space-y-4">
                <Field label="Current Password" type="password" placeholder="••••••••" />
                <Field label="New Password" type="password" placeholder="Min 12 characters" />
                <Field label="Confirm Password" type="password" placeholder="Repeat new password" />
                <SCard className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold text-foreground">Two-Factor Authentication</p>
                      <p className="text-xs text-muted-foreground mt-0.5">Hardware token or authenticator app required</p>
                    </div>
                    <div className="w-10 h-5 bg-primary rounded-full relative cursor-pointer">
                      <div className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow" />
                    </div>
                  </div>
                </SCard>
                <Btn>Update Password</Btn>
              </div>
            </>
          )}
          {tab === "theme" && (
            <>
              <div>
                <h3 className="text-lg font-bold text-foreground">Theme</h3>
                <p className="text-muted-foreground text-sm mt-0.5">Choose your preferred color scheme</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {(["dark", "light"] as const).map(t => (
                  <button
                    key={t}
                    onClick={() => { if (theme !== t) toggle(); }}
                    className={`rounded-xl border-2 p-4 text-left transition-all ${theme === t ? "border-primary bg-primary/8" : "border-border hover:border-border/80 bg-card"}`}
                  >
                    <div className={`h-24 rounded-lg mb-3 flex overflow-hidden ${t === "dark" ? "bg-[#161A1F]" : "bg-[#EEF2F6]"}`}>
                      <div className={`w-10 h-full ${t === "dark" ? "bg-[#1A2027]" : "bg-[#1A2027]"} flex flex-col pt-3 gap-1.5 px-1.5`}>
                        {[...Array(4)].map((_, i) => (
                          <div key={i} className={`h-1.5 rounded-full ${i === 0 ? "bg-[#5CA9C7]" : "bg-[#323A44]"}`} />
                        ))}
                      </div>
                      <div className="flex-1 p-2 flex flex-col gap-1.5">
                        <div className={`h-6 rounded ${t === "dark" ? "bg-[#252C34]" : "bg-white"}`} />
                        <div className="grid grid-cols-2 gap-1 flex-1">
                          <div className={`rounded ${t === "dark" ? "bg-[#252C34]" : "bg-white"}`} />
                          <div className={`rounded ${t === "dark" ? "bg-[#252C34]" : "bg-white"}`} />
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold text-foreground capitalize">{t} Mode</p>
                        <p className="text-xs text-muted-foreground mt-0.5">{t === "dark" ? "Low-light optimized" : "Daytime briefing"}</p>
                      </div>
                      {theme === t && <Check size={16} className="text-primary shrink-0" />}
                    </div>
                  </button>
                ))}
              </div>
              <SCard className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-semibold text-foreground">Current theme</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Toggle with the sun/moon icon in the top bar</p>
                  </div>
                  <button onClick={toggle}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium">
                    {theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}
                    {theme === "dark" ? "Light Mode" : "Dark Mode"}
                  </button>
                </div>
              </SCard>
            </>
          )}
          {tab !== "profile" && tab !== "security" && tab !== "theme" && (
            <div className="flex flex-col items-center py-16 text-center">
              <SettingsIcon size={32} className="text-muted-foreground mb-3" />
              <p className="text-dim font-semibold capitalize">{tab} Settings</p>
              <p className="text-muted-foreground text-sm mt-1">Configure your {tab} preferences here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Profile ──────────────────────────────────────────────────────────────────

function ProfilePage({ onLogout }: { onLogout: () => void }) {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <SCard className="p-6 flex items-center gap-6">
        <div className="w-20 h-20 rounded-full bg-primary/15 border-2 border-primary/40 flex items-center justify-center text-primary text-2xl font-bold shrink-0">OC</div>
        <div className="flex-1">
          <h2 className="text-xl font-bold text-foreground">Operator Commander</h2>
          <p className="text-dim text-sm">NAVSPECWARCOM · Operations Commander</p>
          <div className="flex gap-2 mt-2">
            <Badge variant="danger">TOP SECRET</Badge>
            <Badge variant="info">SCI Clearance</Badge>
            <Badge variant="success">Active</Badge>
          </div>
        </div>
        <div className="flex gap-2 shrink-0">
          <Btn variant="secondary" size="sm" icon={<Edit2 size={13} />}>Edit Profile</Btn>
          <Btn variant="danger" size="sm" onClick={onLogout} icon={<LogOut size={13} />}>Logout</Btn>
        </div>
      </SCard>

      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Scenarios Created", value: "84" },
          { label: "Assets Managed", value: "312" },
          { label: "Missions Completed", value: "71" },
          { label: "Collaborators", value: "16" },
        ].map(s => (
          <SCard key={s.label} className="p-4 text-center">
            <p className="text-3xl font-bold text-primary">{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1.5">{s.label}</p>
          </SCard>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <SCard className="p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Recent Work</h3>
          <div className="space-y-2">
            {recentScenarios.map(s => (
              <div key={s.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-muted transition-colors cursor-pointer">
                <div className="w-7 h-7 rounded-lg bg-muted border border-border flex items-center justify-center text-primary shrink-0">
                  {domainIcon(s.type)}
                </div>
                <span className="text-sm text-foreground flex-1 truncate">{s.name}</span>
                <Badge variant={s.status === "active" ? "success" : s.status === "complete" ? "info" : "default"}>{s.status}</Badge>
                <span className="text-xs text-muted-foreground">{s.ago}</span>
              </div>
            ))}
          </div>
        </SCard>
        <SCard className="p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">Preferences</h3>
          <div className="space-y-4">
            {[
              { label: "Email notifications", on: true },
              { label: "Desktop alerts", on: true },
              { label: "Auto-save drafts", on: true },
              { label: "Dark theme", on: true },
            ].map(p => (
              <div key={p.label} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                <span className="text-sm text-dim">{p.label}</span>
                <div className={`w-9 h-5 rounded-full relative cursor-pointer transition-colors ${p.on ? "bg-primary" : "bg-border"}`}>
                  <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${p.on ? "right-0.5" : "left-0.5"}`} />
                </div>
              </div>
            ))}
          </div>
        </SCard>
      </div>
    </div>
  );
}

// ─── Help ─────────────────────────────────────────────────────────────────────

function HelpPage() {
  const [search, setSearch] = useState("");
  const articles = [
    { title: "Getting Started with Scenario Builder", cat: "Tutorials", views: "2.4k" },
    { title: "Creating Your First Scenario", cat: "Tutorials", views: "1.8k" },
    { title: "Understanding Entity Relationships", cat: "Documentation", views: "1.2k" },
    { title: "Mission Timeline Deep Dive", cat: "Documentation", views: "987" },
    { title: "Asset Library Management", cat: "Documentation", views: "834" },
    { title: "Classification & Security Levels", cat: "FAQ", views: "1.1k" },
    { title: "Exporting and Sharing Scenarios", cat: "Tutorials", views: "756" },
    { title: "REST API Integration Guide", cat: "Documentation", views: "623" },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <SCard className="p-8 text-center">
        <div className="w-12 h-12 bg-primary/15 rounded-2xl flex items-center justify-center mx-auto mb-3">
          <HelpIcon size={24} className="text-primary" />
        </div>
        <h2 className="text-xl font-bold text-foreground mb-1">Help Center</h2>
        <p className="text-muted-foreground text-sm mb-5">Search the knowledge base and documentation</p>
        <div className="relative max-w-md mx-auto">
          <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search articles, guides, FAQ..."
            className="w-full h-12 bg-muted border border-border rounded-xl pl-10 pr-4 text-foreground placeholder-muted-foreground outline-none focus:border-primary text-sm transition-colors" />
        </div>
      </SCard>

      <div className="grid grid-cols-4 gap-4">
        {[
          { label: "Documentation", icon: <FileText size={20} />, count: "124 articles" },
          { label: "Tutorials", icon: <Play size={20} />, count: "32 video guides" },
          { label: "FAQ", icon: <HelpCircle size={20} />, count: "64 answers" },
          { label: "Support", icon: <MessageSquare size={20} />, count: "Open a ticket" },
        ].map(c => (
          <SCard key={c.label} className="p-4 text-center cursor-pointer hover:border-primary/40">
            <span className="flex justify-center text-primary mb-2">{c.icon}</span>
            <p className="text-sm font-semibold text-foreground">{c.label}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{c.count}</p>
          </SCard>
        ))}
      </div>

      <SCard className="p-5">
        <h3 className="text-sm font-semibold text-foreground mb-4">Popular Articles</h3>
        <div className="space-y-1">
          {articles.filter(a => a.title.toLowerCase().includes(search.toLowerCase())).map((a, i) => (
            <div key={i}
              className="flex items-center gap-3 p-3 rounded-xl hover:bg-muted transition-colors cursor-pointer group">
              <FileText size={14} className="text-primary shrink-0" />
              <span className="text-sm text-foreground flex-1">{a.title}</span>
              <Badge>{a.cat}</Badge>
              <span className="text-xs text-muted-foreground">{a.views} views</span>
              <ExternalLink size={12} className="text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          ))}
        </div>
      </SCard>
    </div>
  );
}

// ─── Component Library ────────────────────────────────────────────────────────

const COLOR_TOKENS = [
  { name: "Background", token: "--background", hex: "#161A1F", role: "App background" },
  { name: "Sidebar", token: "--sidebar", hex: "#1A2027", role: "Navigation surface" },
  { name: "Surface", token: "--surface", hex: "#1D232A", role: "Panels, headers" },
  { name: "Card", token: "--card", hex: "#252C34", role: "Cards, dropdowns" },
  { name: "Border", token: "--border", hex: "#323A44", role: "Dividers, outlines" },
  { name: "Primary", token: "--primary", hex: "#5CA9C7", role: "Actions, links, focus" },
  { name: "Secondary", token: "--secondary", hex: "#6E8FB8", role: "Secondary accents" },
  { name: "Success", token: "--success", hex: "#4FA76A", role: "Positive states" },
  { name: "Warning", token: "--warning", hex: "#D4A85E", role: "Caution states" },
  { name: "Danger", token: "--danger", hex: "#C96A6A", role: "Error, destructive" },
  { name: "Text", token: "--foreground", hex: "#E8EDF2", role: "Primary text" },
  { name: "Text Secondary", token: "--text-secondary", hex: "#A8B2BF", role: "Labels, secondary" },
  { name: "Muted", token: "--muted-foreground", hex: "#7B8794", role: "Placeholders, hints" },
];

const TYPE_SCALE = [
  { name: "Display", size: "36px", weight: "700", usage: "Hero headings, splash" },
  { name: "Page Title", size: "32px", weight: "700", usage: "Screen titles" },
  { name: "Section Heading", size: "24px", weight: "600", usage: "Section headers" },
  { name: "Card Title", size: "18px", weight: "600", usage: "Card headings" },
  { name: "Body", size: "16px", weight: "400", usage: "Primary content" },
  { name: "Small", size: "14px", weight: "400/500", usage: "Labels, captions" },
  { name: "Caption", size: "12px", weight: "400/500", usage: "Meta, timestamps" },
  { name: "Micro", size: "10px", weight: "600", usage: "Tags, badges, mono" },
];

const SPACING = [4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80];

const ICON_SHOWCASE = [
  { icon: <Target size={20} />, name: "Target" },
  { icon: <Ship size={20} />, name: "Ship" },
  { icon: <Plane size={20} />, name: "Plane" },
  { icon: <Satellite size={20} />, name: "Satellite" },
  { icon: <Shield size={20} />, name: "Shield" },
  { icon: <Anchor size={20} />, name: "Anchor" },
  { icon: <Radio size={20} />, name: "Radio" },
  { icon: <Navigation size={20} />, name: "Navigation" },
  { icon: <Zap size={20} />, name: "Zap" },
  { icon: <Globe size={20} />, name: "Globe" },
  { icon: <Activity size={20} />, name: "Activity" },
  { icon: <BarChart3 size={20} />, name: "BarChart3" },
  { icon: <TrendingUp size={20} />, name: "TrendingUp" },
  { icon: <Clock size={20} />, name: "Clock" },
  { icon: <MapPin size={20} />, name: "MapPin" },
  { icon: <Tag size={20} />, name: "Tag" },
  { icon: <Lock size={20} />, name: "Lock" },
  { icon: <Eye size={20} />, name: "Eye" },
  { icon: <Search size={20} />, name: "Search" },
  { icon: <Filter size={20} />, name: "Filter" },
  { icon: <Download size={20} />, name: "Download" },
  { icon: <Upload size={20} />, name: "Upload" },
  { icon: <Edit2 size={20} />, name: "Edit2" },
  { icon: <Trash2 size={20} />, name: "Trash2" },
  { icon: <Copy size={20} />, name: "Copy" },
  { icon: <Save size={20} />, name: "Save" },
  { icon: <Plus size={20} />, name: "Plus" },
  { icon: <X size={20} />, name: "X" },
  { icon: <Check size={20} />, name: "Check" },
  { icon: <AlertTriangle size={20} />, name: "AlertTriangle" },
  { icon: <Info size={20} />, name: "Info" },
  { icon: <Bell size={20} />, name: "Bell" },
  { icon: <Star size={20} />, name: "Star" },
  { icon: <Home size={20} />, name: "Home" },
  { icon: <Bookmark size={20} />, name: "Bookmark" },
  { icon: <Send size={20} />, name: "Send" },
  { icon: <RefreshCw size={20} />, name: "RefreshCw" },
  { icon: <ArrowRight size={20} />, name: "ArrowRight" },
  { icon: <ExternalLink size={20} />, name: "ExternalLink" },
  { icon: <MessageSquare size={20} />, name: "MessageSquare" },
];

function Section({ title, id, children }: { title: string; id: string; children: React.ReactNode }) {
  return (
    <section id={id} className="scroll-mt-6">
      <div className="flex items-center gap-3 mb-5">
        <h2 className="text-sm font-bold text-foreground uppercase tracking-widest">{title}</h2>
        <div className="flex-1 h-px bg-border" />
        <span className="text-xs font-mono text-muted-foreground px-2 py-0.5 bg-card rounded border border-border">#{id}</span>
      </div>
      {children}
    </section>
  );
}

// ── Download helpers ──────────────────────────────────────────────────────────

function downloadFile(content: string, filename: string, mimeType: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function buildTokensJSON(): string {
  const tokens = {
    "$schema": "https://design-tokens.org/schema/2024",
    "meta": {
      "name": "Scenario Builder Design System",
      "version": "4.2.1",
      "exported": new Date().toISOString(),
      "author": "Scenario Builder · ITAR Controlled",
    },
    "colors": {
      "background":    { "$value": "#161A1F", "$type": "color", "$description": "App canvas background" },
      "sidebar":       { "$value": "#1A2027", "$type": "color", "$description": "Navigation sidebar surface" },
      "surface":       { "$value": "#1D232A", "$type": "color", "$description": "Panels, top bars, headers" },
      "card":          { "$value": "#252C34", "$type": "color", "$description": "Cards, dropdowns, popovers" },
      "hover":         { "$value": "#2D3640", "$type": "color", "$description": "Interactive hover state" },
      "border":        { "$value": "#323A44", "$type": "color", "$description": "Dividers, outlines, table lines" },
      "primary":       { "$value": "#5CA9C7", "$type": "color", "$description": "Primary actions, links, focus ring" },
      "secondary":     { "$value": "#6E8FB8", "$type": "color", "$description": "Secondary accents, charts" },
      "success":       { "$value": "#4FA76A", "$type": "color", "$description": "Positive states, active badges" },
      "warning":       { "$value": "#D4A85E", "$type": "color", "$description": "Caution states, drafts" },
      "danger":        { "$value": "#C96A6A", "$type": "color", "$description": "Errors, destructive actions" },
      "text":          { "$value": "#E8EDF2", "$type": "color", "$description": "Primary text" },
      "textSecondary": { "$value": "#A8B2BF", "$type": "color", "$description": "Labels, secondary copy" },
      "muted":         { "$value": "#7B8794", "$type": "color", "$description": "Placeholders, hints, meta" },
    },
    "typography": {
      "fontFamily": { "$value": "Inter, sans-serif", "$type": "fontFamily" },
      "lineHeight":  { "$value": "1.5", "$type": "number" },
      "scale": {
        "display":         { "$value": { "fontFamily": "Inter", "fontWeight": "700", "fontSize": "36px", "lineHeight": "150%" }, "$type": "typography" },
        "pageTitle":       { "$value": { "fontFamily": "Inter", "fontWeight": "700", "fontSize": "32px", "lineHeight": "150%" }, "$type": "typography" },
        "sectionHeading":  { "$value": { "fontFamily": "Inter", "fontWeight": "600", "fontSize": "24px", "lineHeight": "150%" }, "$type": "typography" },
        "cardTitle":       { "$value": { "fontFamily": "Inter", "fontWeight": "600", "fontSize": "18px", "lineHeight": "150%" }, "$type": "typography" },
        "body":            { "$value": { "fontFamily": "Inter", "fontWeight": "400", "fontSize": "16px", "lineHeight": "150%" }, "$type": "typography" },
        "small":           { "$value": { "fontFamily": "Inter", "fontWeight": "400", "fontSize": "14px", "lineHeight": "150%" }, "$type": "typography" },
        "caption":         { "$value": { "fontFamily": "Inter", "fontWeight": "400", "fontSize": "12px", "lineHeight": "150%" }, "$type": "typography" },
        "micro":           { "$value": { "fontFamily": "Inter", "fontWeight": "600", "fontSize": "10px", "lineHeight": "150%" }, "$type": "typography" },
      },
    },
    "spacing": {
      "1": { "$value": "4px",  "$type": "dimension" },
      "2": { "$value": "8px",  "$type": "dimension" },
      "3": { "$value": "12px", "$type": "dimension" },
      "4": { "$value": "16px", "$type": "dimension" },
      "5": { "$value": "20px", "$type": "dimension" },
      "6": { "$value": "24px", "$type": "dimension" },
      "8": { "$value": "32px", "$type": "dimension" },
      "10": { "$value": "40px", "$type": "dimension" },
      "12": { "$value": "48px", "$type": "dimension" },
      "16": { "$value": "64px", "$type": "dimension" },
      "20": { "$value": "80px", "$type": "dimension" },
    },
    "borderRadius": {
      "sm":   { "$value": "4px",    "$type": "dimension", "$description": "Tags, chips" },
      "md":   { "$value": "8px",    "$type": "dimension", "$description": "Inputs, small buttons" },
      "lg":   { "$value": "12px",   "$type": "dimension", "$description": "Base radius" },
      "xl":   { "$value": "16px",   "$type": "dimension", "$description": "Cards, modals" },
      "2xl":  { "$value": "20px",   "$type": "dimension", "$description": "Large panels" },
      "full": { "$value": "9999px", "$type": "dimension", "$description": "Pills, avatars, toggles" },
    },
    "sizing": {
      "topbarHeight":    { "$value": "72px",  "$type": "dimension" },
      "sidebarWidth":    { "$value": "280px", "$type": "dimension" },
      "sidebarCollapsed":{ "$value": "88px",  "$type": "dimension" },
      "rightPanelWidth": { "$value": "360px", "$type": "dimension" },
      "inputHeight":     { "$value": "48px",  "$type": "dimension" },
      "buttonHeight":    { "$value": "44px",  "$type": "dimension" },
    },
    "shadow": {
      "sm":  { "$value": "0 1px 3px rgba(0,0,0,0.4)", "$type": "shadow" },
      "md":  { "$value": "0 4px 12px rgba(0,0,0,0.5)", "$type": "shadow" },
      "lg":  { "$value": "0 8px 24px rgba(0,0,0,0.6)", "$type": "shadow" },
      "glow":{ "$value": "0 0 16px rgba(92,169,199,0.2)", "$type": "shadow" },
    },
    "motion": {
      "duration": {
        "fast":   { "$value": "120ms", "$type": "duration" },
        "base":   { "$value": "200ms", "$type": "duration" },
        "slow":   { "$value": "350ms", "$type": "duration" },
        "spring": { "$value": "450ms", "$type": "duration" },
      },
      "easing": {
        "default": { "$value": "cubic-bezier(0.4,0,0.2,1)", "$type": "cubicBezier" },
        "spring":  { "$value": "cubic-bezier(0.34,1.56,0.64,1)", "$type": "cubicBezier" },
      },
    },
  };
  return JSON.stringify(tokens, null, 2);
}

function buildCSSVars(): string {
  return `/* ============================================================
   Scenario Builder — CSS Design Tokens
   Generated: ${new Date().toISOString()}
   Version: 4.2.1 · ITAR Controlled
   ============================================================ */

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
  /* ── Font ───────────────────────────────────────── */
  --font-family: 'Inter', sans-serif;
  --font-size-base: 16px;
  --line-height: 1.5;

  /* ── Color — Surfaces ───────────────────────────── */
  --color-background:  #161A1F;
  --color-sidebar:     #1A2027;
  --color-surface:     #1D232A;
  --color-card:        #252C34;
  --color-hover:       #2D3640;
  --color-border:      #323A44;

  /* ── Color — Brand ──────────────────────────────── */
  --color-primary:     #5CA9C7;
  --color-secondary:   #6E8FB8;

  /* ── Color — Semantic ───────────────────────────── */
  --color-success:     #4FA76A;
  --color-warning:     #D4A85E;
  --color-danger:      #C96A6A;

  /* ── Color — Text ───────────────────────────────── */
  --color-text:           #E8EDF2;
  --color-text-secondary: #A8B2BF;
  --color-text-muted:     #7B8794;

  /* ── Typography ─────────────────────────────────── */
  --text-display:   36px / 700;
  --text-page:      32px / 700;
  --text-section:   24px / 600;
  --text-card:      18px / 600;
  --text-body:      16px / 400;
  --text-small:     14px / 400;
  --text-caption:   12px / 400;
  --text-micro:     10px / 600;

  /* ── Spacing (8-point) ──────────────────────────── */
  --space-1:   4px;
  --space-2:   8px;
  --space-3:   12px;
  --space-4:   16px;
  --space-5:   20px;
  --space-6:   24px;
  --space-8:   32px;
  --space-10:  40px;
  --space-12:  48px;
  --space-16:  64px;
  --space-20:  80px;

  /* ── Border Radius ──────────────────────────────── */
  --radius-sm:   4px;
  --radius-md:   8px;
  --radius-lg:   12px;
  --radius-xl:   16px;
  --radius-2xl:  20px;
  --radius-full: 9999px;

  /* ── Sizing ─────────────────────────────────────── */
  --topbar-height:      72px;
  --sidebar-width:      280px;
  --sidebar-collapsed:  88px;
  --right-panel-width:  360px;
  --input-height:       48px;
  --button-height:      44px;

  /* ── Shadow ─────────────────────────────────────── */
  --shadow-sm:   0 1px 3px rgba(0, 0, 0, 0.4);
  --shadow-md:   0 4px 12px rgba(0, 0, 0, 0.5);
  --shadow-lg:   0 8px 24px rgba(0, 0, 0, 0.6);
  --shadow-glow: 0 0 16px rgba(92, 169, 199, 0.2);

  /* ── Motion ─────────────────────────────────────── */
  --duration-fast:   120ms;
  --duration-base:   200ms;
  --duration-slow:   350ms;
  --easing-default:  cubic-bezier(0.4, 0, 0.2, 1);
  --easing-spring:   cubic-bezier(0.34, 1.56, 0.64, 1);
}

/* ── Utility Classes ──────────────────────────────────────── */

.sb-btn-primary {
  background: var(--color-primary);
  color: var(--color-background);
  height: var(--button-height);
  padding: 0 20px;
  border-radius: var(--radius-lg);
  font-weight: 600;
  font-size: 14px;
  transition: opacity var(--duration-base) var(--easing-default);
}
.sb-btn-secondary {
  background: var(--color-card);
  color: var(--color-text);
  border: 1px solid var(--color-border);
  height: var(--button-height);
  padding: 0 20px;
  border-radius: var(--radius-lg);
  font-weight: 600;
  font-size: 14px;
}
.sb-input {
  background: var(--color-card);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  height: var(--input-height);
  padding: 0 16px;
  color: var(--color-text);
  font-size: 14px;
  font-family: var(--font-family);
  transition: border-color var(--duration-fast) var(--easing-default);
}
.sb-input:focus {
  border-color: var(--color-primary);
  outline: none;
  box-shadow: 0 0 0 3px rgba(92, 169, 199, 0.15);
}
.sb-card {
  background: var(--color-card);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-xl);
  padding: var(--space-6);
}
.sb-badge {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: var(--radius-md);
  font-size: 12px;
  font-weight: 600;
}
.sb-badge-success  { background: rgba(79, 167, 106, 0.2); color: #4FA76A; }
.sb-badge-warning  { background: rgba(212, 168, 94, 0.2);  color: #D4A85E; }
.sb-badge-danger   { background: rgba(201, 106, 106, 0.2); color: #C96A6A; }
.sb-badge-info     { background: rgba(92, 169, 199, 0.2);  color: #5CA9C7; }
`;
}

function buildHTMLDoc(): string {
  const ts = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
  const colors = COLOR_TOKENS.map(c =>
    `<div class="swatch"><div class="chip" style="background:${c.hex}"></div>
     <b>${c.name}</b><code>${c.hex}</code><span>${c.role}</span></div>`
  ).join("\n");
  const types = TYPE_SCALE.map(t =>
    `<tr><td>${t.name}</td><td>${t.size}</td><td>${t.weight}</td>
     <td style="font-size:${t.size};font-weight:${parseInt(t.weight)};color:#E8EDF2">The quick brown fox</td>
     <td>${t.usage}</td></tr>`
  ).join("\n");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Scenario Builder — Design System</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#161A1F;color:#E8EDF2;line-height:1.5;display:flex}
nav{width:220px;min-height:100vh;background:#1A2027;border-right:1px solid #323A44;padding:32px 16px;position:sticky;top:0;flex-shrink:0}
nav h2{font-size:11px;font-weight:700;color:#7B8794;text-transform:uppercase;letter-spacing:.1em;margin:20px 0 8px;padding:0 8px}
nav h2:first-child{margin-top:0}
nav a{display:block;padding:7px 10px;border-radius:8px;font-size:13px;color:#A8B2BF;text-decoration:none;margin-bottom:2px;transition:all .15s}
nav a:hover{background:#252C34;color:#E8EDF2}
.content{flex:1;padding:56px 64px;max-width:1060px}
.page-title{font-size:32px;font-weight:700;margin-bottom:8px}
.meta{color:#7B8794;font-size:14px;margin-bottom:56px}
section{margin-bottom:72px}
.section-label{font-size:10px;font-weight:700;color:#5CA9C7;text-transform:uppercase;letter-spacing:.12em;margin-bottom:20px;display:flex;align-items:center;gap:10px}
.section-label::after{content:'';flex:1;height:1px;background:#323A44}
h3{font-size:14px;font-weight:600;color:#A8B2BF;margin:28px 0 12px}
.swatches{display:grid;grid-template-columns:repeat(7,1fr);gap:12px;margin-bottom:8px}
.swatch{display:flex;flex-direction:column;gap:5px}
.chip{width:100%;aspect-ratio:1;border-radius:10px;border:1px solid #323A44}
.swatch b{font-size:11px;font-weight:600;color:#E8EDF2}
.swatch code{font-size:10px;color:#5CA9C7;font-family:monospace}
.swatch span{font-size:10px;color:#7B8794}
.surfaces{display:flex;gap:8px;margin-bottom:16px}
.surface{flex:1;height:52px;border-radius:10px;border:1px solid #323A44;display:flex;align-items:flex-end;padding:5px 8px;font-size:9px;color:#7B8794;flex-direction:column;justify-content:flex-end}
table{width:100%;border-collapse:collapse;background:#1D232A;border:1px solid #323A44;border-radius:10px;overflow:hidden;margin-bottom:16px}
th{text-align:left;padding:9px 14px;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:#7B8794;border-bottom:1px solid #323A44;background:#252C34}
td{padding:11px 14px;border-bottom:1px solid #323A44;font-size:12px;color:#A8B2BF}
tr:last-child td{border-bottom:none}
.btn-row{display:flex;gap:10px;flex-wrap:wrap;margin:8px 0}
.btn{display:inline-flex;align-items:center;gap:8px;height:44px;padding:0 20px;border-radius:12px;font-size:13px;font-weight:600;cursor:default;border:none;font-family:'Inter',sans-serif}
.btn-primary{background:#5CA9C7;color:#161A1F}
.btn-secondary{background:#252C34;color:#E8EDF2;border:1px solid #323A44}
.btn-ghost{background:transparent;color:#A8B2BF;border:1px solid #323A44}
.btn-danger{background:rgba(201,106,106,.15);color:#C96A6A;border:1px solid rgba(201,106,106,.3)}
.btn-sm{height:34px;padding:0 14px;font-size:12px;border-radius:8px}
.btn-lg{height:52px;padding:0 28px;font-size:15px}
.badge{display:inline-flex;align-items:center;padding:3px 8px;border-radius:6px;font-size:11px;font-weight:600;margin:2px}
.badge-default{background:#323A44;color:#A8B2BF}
.badge-success{background:rgba(79,167,106,.2);color:#4FA76A}
.badge-warning{background:rgba(212,168,94,.2);color:#D4A85E}
.badge-danger{background:rgba(201,106,106,.2);color:#C96A6A}
.badge-info{background:rgba(92,169,199,.2);color:#5CA9C7}
.input-demo{background:#252C34;border:1px solid #323A44;border-radius:10px;height:44px;padding:0 14px;color:#E8EDF2;font-size:13px;font-family:'Inter',sans-serif;width:100%;max-width:320px}
.input-demo:focus{outline:none;border-color:#5CA9C7;box-shadow:0 0 0 3px rgba(92,169,199,.15)}
.spacing-row{display:flex;align-items:center;gap:10px;margin:4px 0}
.spacing-bar{height:18px;background:rgba(92,169,199,.25);border:1px solid rgba(92,169,199,.4);border-radius:3px}
code{font-family:monospace;font-size:11px;color:#5CA9C7;background:#252C34;padding:1px 5px;border-radius:4px}
.card-demo{background:#252C34;border:1px solid #323A44;border-radius:14px;padding:20px}
.card-title{font-size:15px;font-weight:600;margin-bottom:6px}
.card-body{font-size:13px;color:#A8B2BF}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
.anim-row{display:flex;align-items:center;gap:10px;padding:10px 14px;background:#252C34;border:1px solid #323A44;border-radius:10px;margin-bottom:8px}
.anim-bar{height:6px;border-radius:3px;background:linear-gradient(90deg,#5CA9C7,#6E8FB8)}
.flow-step{display:flex;align-items:center;gap:0}
.flow-node{background:#252C34;border:1px solid #5CA9C7;border-radius:10px;padding:8px 14px;font-size:12px;white-space:nowrap}
.flow-arrow{color:#5CA9C7;padding:0 8px;font-size:16px}
.proto-section{background:#1D232A;border:1px solid #323A44;border-radius:12px;padding:20px;margin-bottom:12px}
.proto-title{font-size:13px;font-weight:600;color:#E8EDF2;margin-bottom:12px;display:flex;align-items:center;gap:8px}
.proto-chip{font-size:10px;font-weight:600;background:#5CA9C7;color:#161A1F;border-radius:4px;padding:2px 6px}
footer{margin-top:80px;padding:24px 0;border-top:1px solid #323A44;font-size:11px;color:#7B8794;text-align:center}
</style>
</head>
<body>
<nav>
  <h2 style="margin-top:0">Foundation</h2>
  <a href="#colors">Color Tokens</a>
  <a href="#surfaces">Surface Hierarchy</a>
  <a href="#typography">Typography</a>
  <a href="#spacing">Spacing</a>
  <a href="#radius">Border Radius</a>
  <h2>Components</h2>
  <a href="#buttons">Buttons</a>
  <a href="#inputs">Inputs</a>
  <a href="#badges">Badges</a>
  <a href="#cards">Cards</a>
  <a href="#classify">Classification</a>
  <h2>Patterns</h2>
  <a href="#prototypes">Prototype Flows</a>
  <a href="#animations">Animation Spec</a>
  <a href="#interactions">Interaction States</a>
  <a href="#layout">Layout Grid</a>
</nav>

<div class="content">
<p class="page-title">Scenario Builder</p>
<p class="meta">Design System · v4.2.1 · ${ts} · ITAR Controlled · Authorized Use Only</p>

<section id="colors">
<div class="section-label">Color Tokens</div>
<div class="swatches">${colors}</div>
</section>

<section id="surfaces">
<div class="section-label">Surface Hierarchy</div>
<div class="surfaces">
${["#161A1F:Background:z-0","#1A2027:Sidebar:z-sidebar","#1D232A:Surface:z-1","#252C34:Card:z-2","#2D3640:Hover:z-interactive","#323A44:Border:—"].map(s => {
  const [hex, label, z] = s.split(":");
  return `<div class="surface" style="background:${hex}"><code>${hex}</code><b style="font-size:11px;color:#A8B2BF">${label}</b></div>`;
}).join("\n")}
</div>
</section>

<section id="typography">
<div class="section-label">Typography Scale — Inter</div>
<table>
<thead><tr><th>Token</th><th>Size</th><th>Weight</th><th>Preview</th><th>Usage</th></tr></thead>
<tbody>${types}</tbody>
</table>
</section>

<section id="spacing">
<div class="section-label">Spacing — 8-Point Grid</div>
${SPACING.map(s => `<div class="spacing-row"><code style="width:44px;display:inline-block">${s}px</code><div class="spacing-bar" style="width:${Math.min(s * 3, 480)}px"></div><span style="font-size:11px;color:#7B8794">sp-${SPACING.indexOf(s)+1}</span></div>`).join("\n")}
</section>

<section id="radius">
<div class="section-label">Border Radius</div>
<div style="display:flex;gap:16px;flex-wrap:wrap">
${[["4px","sm","Tags, chips"],["8px","md","Inputs"],["12px","lg","Buttons, base"],["16px","xl","Cards"],["20px","2xl","Large panels"],["9999px","full","Pills, avatars"]].map(([r, n, u]) =>
  `<div style="text-align:center">
    <div style="width:56px;height:40px;background:rgba(92,169,199,.15);border:1px solid rgba(92,169,199,.4);border-radius:${r};margin-bottom:6px"></div>
    <code>${n}</code><br><span style="font-size:10px;color:#7B8794">${r}</span><br><span style="font-size:10px;color:#5C6A7A">${u}</span>
  </div>`).join("\n")}
</div>
</section>

<section id="buttons">
<div class="section-label">Buttons</div>
<h3>Sizes</h3>
<div class="btn-row">
  <button class="btn btn-primary btn-sm">Small</button>
  <button class="btn btn-primary">Default (44px)</button>
  <button class="btn btn-primary btn-lg">Large</button>
</div>
<h3>Variants</h3>
<div class="btn-row">
  <button class="btn btn-primary">Primary</button>
  <button class="btn btn-secondary">Secondary</button>
  <button class="btn btn-ghost">Ghost</button>
  <button class="btn btn-danger">Danger</button>
</div>
<h3>States</h3>
<div class="btn-row">
  <button class="btn btn-primary" style="opacity:1">Default</button>
  <button class="btn btn-primary" style="opacity:.75">Hover</button>
  <button class="btn btn-primary" style="opacity:.55">Pressed</button>
  <button class="btn btn-primary" style="opacity:.35;cursor:not-allowed">Disabled</button>
</div>
</section>

<section id="inputs">
<div class="section-label">Form Inputs</div>
<h3>Text Input</h3>
<input class="input-demo" placeholder="Placeholder text…" /><br><br>
<input class="input-demo" value="Filled value" /><br><br>
<input class="input-demo" style="border-color:#5CA9C7;box-shadow:0 0 0 3px rgba(92,169,199,.15)" value="Focused state" /><br><br>
<input class="input-demo" style="border-color:#C96A6A;box-shadow:0 0 0 3px rgba(201,106,106,.15)" value="Error state" />
</section>

<section id="badges">
<div class="section-label">Badges &amp; Tags</div>
<h3>Status</h3>
<div>
  <span class="badge badge-default">Default</span>
  <span class="badge badge-success">Active</span>
  <span class="badge badge-warning">Review</span>
  <span class="badge badge-danger">Critical</span>
  <span class="badge badge-info">In Progress</span>
</div>
<h3>Classification Tags</h3>
<div>
${[["UNCLASSIFIED","#4FA76A","#161A1F"],["CONFIDENTIAL","#6E8FB8","#fff"],["SECRET","#D4A85E","#161A1F"],["TOP SECRET","#C96A6A","#fff"],["TOP SECRET // SCI","#8B4A4A","#fff"]].map(([l, bg, c]) => `<span class="badge" style="background:${bg};color:${c};margin:2px 4px 2px 0">${l}</span>`).join("")}
</div>
</section>

<section id="cards">
<div class="section-label">Cards</div>
<div class="grid2">
<div class="card-demo">
  <div class="card-title">Neptune Strike</div>
  <div class="card-body">Naval interdiction scenario with 14 entities across 3 theatres.</div>
  <div style="margin-top:12px;display:flex;gap:6px">
    <span class="badge badge-success">Active</span>
    <span class="badge badge-danger">Critical</span>
  </div>
</div>
<div class="card-demo">
  <div class="card-title">Desert Shield Alpha</div>
  <div class="card-body">Land-air combined arms exercise with ISR integration.</div>
  <div style="margin-top:12px;display:flex;gap:6px">
    <span class="badge badge-warning">Review</span>
    <span class="badge badge-info">In Progress</span>
  </div>
</div>
</div>
</section>

<section id="classify">
<div class="section-label">Classification System</div>
<table>
<thead><tr><th>Level</th><th>Color</th><th>Hex</th><th>Usage</th></tr></thead>
<tbody>
${[["UNCLASSIFIED","#4FA76A","Public exercise data"],["CONFIDENTIAL","#6E8FB8","Unit-level operational"],["SECRET","#D4A85E","Theater-level planning"],["TOP SECRET","#C96A6A","National-level intelligence"],["TOP SECRET // SCI","#8B4A4A","Compartmented SI/TK"]].map(([l,c,u])=>`<tr><td><span class="badge" style="background:${c}25;color:${c}">${l}</span></td><td><code>${c}</code></td><td>${c}</td><td style="font-size:12px">${u}</td></tr>`).join("")}
</tbody>
</table>
</section>

<section id="prototypes">
<div class="section-label">Prototype Flows</div>

<div class="proto-section">
<div class="proto-title"><span class="proto-chip">FLOW 1</span> Authentication</div>
<div class="flow-step">
  <div class="flow-node">Splash</div><div class="flow-arrow">→</div>
  <div class="flow-node">Login</div><div class="flow-arrow">→</div>
  <div class="flow-node">Dashboard</div>
</div>
<div style="margin-top:8px;font-size:11px;color:#7B8794">Alternate: Login → Sign Up → Dashboard</div>
</div>

<div class="proto-section">
<div class="proto-title"><span class="proto-chip">FLOW 2</span> Scenario Creation (8-Step Wizard)</div>
<div class="flow-step" style="flex-wrap:wrap;gap:6px">
  ${["1 General","2 Environment","3 Assets","4 Configure","5 Relationships","6 Timeline","7 Review","8 Generate"].map(s => `<div class="flow-node" style="font-size:11px">${s}</div><div class="flow-arrow">→</div>`).join("").slice(0,-35)}
</div>
<div style="margin-top:8px;font-size:11px;color:#7B8794">Each step validates before advancing · Save Draft available at all steps · Cancel returns to Dashboard</div>
</div>

<div class="proto-section">
<div class="proto-title"><span class="proto-chip">FLOW 3</span> Scenario Library Actions</div>
<table style="margin:0">
<thead><tr><th>Trigger</th><th>Action</th><th>Destination</th></tr></thead>
<tbody>
  <tr><td>Row click</td><td>Open PDF Preview Drawer</td><td>Drawer slide-in from right (680px)</td></tr>
  <tr><td>Edit icon</td><td>Open wizard at step 7 (Review)</td><td>Create Scenario screen</td></tr>
  <tr><td>Duplicate</td><td>Clone scenario + toast confirm</td><td>Stays on Library</td></tr>
  <tr><td>Delete</td><td>Confirm modal → remove row</td><td>Stays on Library</td></tr>
  <tr><td>Grid toggle</td><td>Animate layout switch</td><td>Card grid view</td></tr>
</tbody>
</table>
</div>

<div class="proto-section">
<div class="proto-title"><span class="proto-chip">FLOW 4</span> PDF Preview Drawer</div>
<div class="flow-step">
  <div class="flow-node">Library Row</div><div class="flow-arrow">→</div>
  <div class="flow-node">Drawer opens (350ms spring)</div><div class="flow-arrow">→</div>
  <div class="flow-node">5-section document</div>
</div>
<div style="margin-top:8px;font-size:11px;color:#7B8794">Sections: Mission Parameters · Overview · Entity Roster · Timeline · Approval · Actions: Export PDF, Export JSON, Close</div>
</div>
</section>

<section id="animations">
<div class="section-label">Animation Spec</div>
<table>
<thead><tr><th>Token</th><th>Duration</th><th>Easing</th><th>Used For</th></tr></thead>
<tbody>
  <tr><td><code>fast</code></td><td>120ms</td><td>ease-in-out</td><td>Button states, badge appears, icon transitions</td></tr>
  <tr><td><code>base</code></td><td>200ms</td><td>cubic-bezier(0.4,0,0.2,1)</td><td>All hover/active states, tab switches, toggles</td></tr>
  <tr><td><code>slow</code></td><td>350ms</td><td>cubic-bezier(0.4,0,0.2,1)</td><td>Page transitions (opacity fade), sidebar collapse</td></tr>
  <tr><td><code>spring</code></td><td>450ms</td><td>spring(damping:24, stiffness:320)</td><td>Modals, drawers, dropdowns, accordion expand</td></tr>
  <tr><td><code>skeleton</code></td><td>1400ms</td><td>ease-in-out, infinite</td><td>Loading skeleton shimmer (2s cycle)</td></tr>
</tbody>
</table>

<h3>Motion Patterns</h3>
<div class="anim-row"><div style="flex:1"><b style="font-size:13px">Page transition</b><br><span style="font-size:11px;color:#7B8794">opacity: 0→1, duration: 120ms, exit: 80ms</span></div><div class="anim-bar" style="width:80px"></div></div>
<div class="anim-row"><div style="flex:1"><b style="font-size:13px">Sidebar collapse</b><br><span style="font-size:11px;color:#7B8794">width: 280px→88px, spring(stiffness:280, damping:28)</span></div><div class="anim-bar" style="width:120px"></div></div>
<div class="anim-row"><div style="flex:1"><b style="font-size:13px">Drawer slide-in</b><br><span style="font-size:11px;color:#7B8794">x: 680px→0, spring(stiffness:320, damping:30)</span></div><div class="anim-bar" style="width:100px"></div></div>
<div class="anim-row"><div style="flex:1"><b style="font-size:13px">Accordion expand</b><br><span style="font-size:11px;color:#7B8794">height: 0→auto, opacity: 0→1, 200ms ease</span></div><div class="anim-bar" style="width:60px"></div></div>
<div class="anim-row"><div style="flex:1"><b style="font-size:13px">Modal scale-in</b><br><span style="font-size:11px;color:#7B8794">scale: 0.95→1, y: 12→0, spring(stiffness:320, damping:24)</span></div><div class="anim-bar" style="width:90px"></div></div>
<div class="anim-row"><div style="flex:1"><b style="font-size:13px">Splash radar pulse</b><br><span style="font-size:11px;color:#7B8794">scale: 0→2.5, opacity: 0.4→0, 2000ms ease-out, staggered rings</span></div><div class="anim-bar" style="width:140px"></div></div>
</section>

<section id="interactions">
<div class="section-label">Interaction States</div>
<table>
<thead><tr><th>Component</th><th>Default</th><th>Hover</th><th>Pressed/Active</th><th>Focus</th><th>Disabled</th></tr></thead>
<tbody>
  <tr><td>Primary Button</td><td>bg #5CA9C7</td><td>opacity .85</td><td>scale .97</td><td>ring 3px #5CA9C7/40</td><td>opacity .35, cursor:not-allowed</td></tr>
  <tr><td>Nav Item</td><td>transparent</td><td>bg #252C34</td><td>bg #5CA9C7/15, text #5CA9C7</td><td>ring 2px #5CA9C7/60</td><td>—</td></tr>
  <tr><td>Card</td><td>border #323A44</td><td>border #5CA9C7/30, translateY(-1px)</td><td>translateY(0)</td><td>ring 2px #5CA9C7/40</td><td>opacity .5</td></tr>
  <tr><td>Input</td><td>border #323A44</td><td>border #4a5567</td><td>—</td><td>border #5CA9C7, shadow 3px #5CA9C7/15</td><td>opacity .4, bg #1A2027</td></tr>
  <tr><td>Table Row</td><td>transparent</td><td>bg #1D232A</td><td>bg #252C34</td><td>—</td><td>—</td></tr>
  <tr><td>Toggle Switch</td><td>bg #323A44, knob left</td><td>opacity .85</td><td>—</td><td>ring 2px #5CA9C7/40</td><td>opacity .4</td></tr>
</tbody>
</table>
</section>

<section id="layout">
<div class="section-label">Layout Grid</div>
<table>
<thead><tr><th>Token</th><th>Value</th><th>Description</th></tr></thead>
<tbody>
  <tr><td>Canvas</td><td>1440 × 1024px</td><td>Design target frame</td></tr>
  <tr><td>Grid columns</td><td>12</td><td>—</td></tr>
  <tr><td>Margin</td><td>80px</td><td>Left + right</td></tr>
  <tr><td>Gutter</td><td>24px</td><td>Column gap</td></tr>
  <tr><td>Sidebar</td><td>280px / 88px collapsed</td><td>Left navigation</td></tr>
  <tr><td>Top bar</td><td>72px</td><td>Fixed header</td></tr>
  <tr><td>Right panel</td><td>360px</td><td>Dashboard activity panel</td></tr>
  <tr><td>PDF drawer</td><td>680px</td><td>Scenario preview</td></tr>
  <tr><td>Modal max-width</td><td>520px</td><td>Default dialogs</td></tr>
  <tr><td>Card padding</td><td>24px</td><td>—</td></tr>
  <tr><td>Input height</td><td>48px</td><td>—</td></tr>
  <tr><td>Button height</td><td>44px</td><td>—</td></tr>
</tbody>
</table>
</section>

<footer>Scenario Builder Design System &nbsp;·&nbsp; Inter &nbsp;·&nbsp; 8-point grid &nbsp;·&nbsp; WCAG AA &nbsp;·&nbsp; v4.2.1 &nbsp;·&nbsp; ${ts}</footer>
</div>
</body>
</html>`;
}

function buildPrototypeSpec(): string {
  const ts = new Date().toISOString();
  const spec = {
    "$schema": "https://scenario-builder.dev/prototype-spec/v1",
    "meta": {
      "product": "Scenario Builder",
      "version": "4.2.1",
      "exported": ts,
      "targetCanvas": "1440×1024",
      "classification": "ITAR Controlled",
    },
    "screens": [
      {
        "id": "splash",
        "name": "Splash Screen",
        "path": "/",
        "description": "Animated entry screen with radar rings and loading progress",
        "components": ["AnimatedGrid", "RadarRings", "Logo", "Tagline", "ProgressBar"],
        "animations": [
          { "element": "radar-ring-1", "type": "scale+opacity", "from": { "scale": 0, "opacity": 0.4 }, "to": { "scale": 2.5, "opacity": 0 }, "duration": 2000, "easing": "ease-out", "delay": 0 },
          { "element": "radar-ring-2", "type": "scale+opacity", "from": { "scale": 0, "opacity": 0.4 }, "to": { "scale": 2.5, "opacity": 0 }, "duration": 2000, "easing": "ease-out", "delay": 667 },
          { "element": "radar-ring-3", "type": "scale+opacity", "from": { "scale": 0, "opacity": 0.4 }, "to": { "scale": 2.5, "opacity": 0 }, "duration": 2000, "easing": "ease-out", "delay": 1333 },
          { "element": "progress-bar", "type": "width", "from": "0%", "to": "100%", "duration": 2500, "easing": "ease-in-out" },
          { "element": "grid-background", "type": "custom", "keyframes": "gridPan 20s linear infinite", "opacity": 0.08 },
        ],
        "transitions": [
          { "trigger": "progress-complete", "destination": "login", "type": "fade", "duration": 400 }
        ],
      },
      {
        "id": "login",
        "name": "Login Screen",
        "path": "/login",
        "layout": "split-40/60",
        "leftPanel": { "content": "Aerospace illustration", "elements": ["OceanBackground", "AircraftPaths", "SatelliteOrbit", "RadarCone", "WorldMapGrid", "AnimatedGridLines"] },
        "rightPanel": { "content": "Glass auth card", "width": 420, "padding": 48 },
        "components": ["Field[email]", "Field[password]", "Checkbox[remember]", "Btn[primary:Sign In]", "Btn[ghost:Create Account]", "Link[Forgot password]"],
        "transitions": [
          { "trigger": "sign-in-success", "destination": "dashboard", "type": "fade", "duration": 200 },
          { "trigger": "create-account-click", "destination": "signup", "type": "fade", "duration": 200 }
        ],
      },
      {
        "id": "signup",
        "name": "Sign Up",
        "path": "/signup",
        "layout": "split-40/60",
        "components": ["Field[fullName]", "Field[organization]", "Field[email]", "Field[password]", "Field[confirmPassword]", "Checkbox[terms]", "Btn[primary:Create Account]", "Link[Already have account]"],
        "transitions": [
          { "trigger": "account-created", "destination": "dashboard", "type": "fade", "duration": 200 },
          { "trigger": "login-link", "destination": "login", "type": "fade", "duration": 200 }
        ],
      },
      {
        "id": "dashboard",
        "name": "Dashboard",
        "path": "/dashboard",
        "layout": "sidebar + topbar + main(3-col) + rightPanel",
        "sections": ["QuickActions", "Statistics(4 metrics)", "RecentScenarios", "DraftsList", "RecentActivity", "ContinueEditing", "MissionStatus", "AreaChart(scenarios)", "BarChart(assets)", "PieChart(missions)", "StorageBar"],
        "rightPanel": ["NotificationsFeed", "RecentChanges"],
        "animations": [
          { "element": "metric-cards", "type": "stagger-fade-up", "stagger": 80, "duration": 300 },
          { "element": "charts", "type": "draw-in", "duration": 600, "easing": "ease-out" },
          { "element": "activity-items", "type": "stagger-slide-in", "stagger": 60, "duration": 250 },
        ],
      },
      {
        "id": "create-scenario",
        "name": "Create Scenario Wizard",
        "path": "/create",
        "layout": "sidebar + topbar + wizard",
        "steps": [
          { "step": 1, "id": "general", "label": "General", "fields": ["scenarioName", "missionType", "description", "classification", "location", "date", "time", "priority", "tags", "notes"] },
          { "step": 2, "id": "environment", "label": "Environment", "components": ["EnvCard[Ocean]", "EnvCard[Land]", "EnvCard[Mountain]", "EnvCard[Urban]", "EnvCard[Forest]", "WeatherPanel", "PreviewPanel"] },
          { "step": 3, "id": "assets", "label": "Assets", "components": ["SearchBar", "CategoryTabs[Ships,Aircraft,Missiles,Rockets,Drones,Radar,Satellite,Submarines,Ground]", "EntityGrid", "SelectedCount"] },
          { "step": 4, "id": "configure", "label": "Configure", "components": ["EntityAccordion[General,Position,Movement,Communication,Payload,Status,Notes]", "StickyFooter"] },
          { "step": 5, "id": "relationships", "label": "Relationships", "components": ["NodeGraph", "ConnectionToolbar[Attack,Support,Detection,Communication,Escort,Supply]", "ZoomControls", "UndoRedo"] },
          { "step": 6, "id": "timeline", "label": "Timeline", "components": ["HorizontalTimeline", "PhaseBlocks", "EventItems", "TriggerMarkers", "DependencyLines", "EventDrawer"] },
          { "step": 7, "id": "review", "label": "Review", "components": ["ValidationChecklist", "MissionSummary", "EntitySummary", "TimelineSummary", "WarningsList", "GenerateBtn"] },
          { "step": 8, "id": "generate", "label": "Generate", "components": ["HeroCard", "MissionOverview", "EntityList", "Statistics", "ExportPDF", "ExportJSON", "DuplicateBtn", "DeleteBtn", "EditBtn"] },
        ],
        "stepTransition": { "type": "slide-horizontal", "duration": 300, "easing": "cubic-bezier(0.4,0,0.2,1)" },
        "headerActions": ["SaveDraft", "Cancel", "Back", "Next"],
      },
      {
        "id": "scenario-library",
        "name": "Scenario Library",
        "path": "/library",
        "views": ["table", "grid"],
        "tableColumns": ["Name", "Type", "Status", "Priority", "Entities", "Last Modified", "Owner", "Actions"],
        "gridCard": ["thumbnail", "name", "status", "priority", "entityCount", "lastModified", "actions"],
        "filters": ["status", "priority", "missionType", "owner", "dateRange"],
        "rowActions": ["PDFPreview(FileText icon)", "Edit(Edit2 icon)", "Duplicate(Copy icon)", "Delete(Trash2 icon)"],
        "animations": [
          { "element": "table-rows", "type": "stagger-fade-in", "stagger": 30, "duration": 200 },
          { "element": "view-toggle", "type": "layout-animate", "duration": 350 },
          { "element": "pdf-drawer", "type": "slide-from-right", "startX": 680, "duration": 350, "spring": { "stiffness": 320, "damping": 30 } },
        ],
      },
      {
        "id": "pdf-preview-drawer",
        "name": "PDF Preview Drawer",
        "parentScreen": "scenario-library",
        "width": 680,
        "anchor": "right",
        "overlay": { "opacity": 0.6, "blur": "4px" },
        "sections": [
          { "id": "header", "content": "Classification banner + scenario name + actions" },
          { "id": "mission-parameters", "content": "Grid: Name, Type, Priority, Classification, Location, Date/Time, Commander, Status" },
          { "id": "overview", "content": "Mission description paragraph + key objectives list" },
          { "id": "entity-roster", "content": "Table: Asset, Type, Designation, Status, Location, Armament" },
          { "id": "timeline", "content": "Phase blocks: Insertion, Primary Op, Extraction" },
          { "id": "approval", "content": "Signatures: Commander, Intelligence Officer, Operations" },
        ],
        "actions": ["Export PDF", "Export JSON", "Close Drawer"],
        "animation": { "enter": { "x": 680, "duration": 350, "spring": true }, "exit": { "x": 680, "duration": 280, "easing": "ease-in" } },
      },
    ],
    "navigation": {
      "sidebar": {
        "width": 280,
        "collapsedWidth": 88,
        "collapseAnimation": { "type": "width", "spring": { "stiffness": 280, "damping": 28 } },
        "items": [
          { "id": "dashboard", "label": "Dashboard", "subs": ["Overview", "Analytics", "Activity", "Status"] },
          { "id": "create-scenario", "label": "Create Scenario" },
          { "id": "scenario-library", "label": "Scenario Library", "subs": ["All Scenarios", "Active", "Drafts", "Completed", "Archived", "Shared"] },
          { "id": "asset-library", "label": "Assets", "subs": ["Ships", "Aircraft", "Missiles", "Drones", "Radar", "Submarines", "Satellites", "Ground Assets"] },
          { "id": "reports", "label": "Reports", "subs": ["Overview", "Mission Analytics", "Asset Usage", "Export"] },
          { "id": "notifications", "label": "Notifications", "badge": 3 },
          { "id": "settings", "label": "Settings" },
          { "id": "profile", "label": "Profile" },
          { "id": "help", "label": "Help" },
          { "id": "component-library", "label": "Component Library", "position": "bottom" },
        ],
        "accordionAnimation": { "height": "0→auto", "opacity": "0→1", "duration": 200, "easing": "ease-out" },
      },
      "topbar": {
        "height": 72,
        "elements": ["Search", "NotificationBell(badge)", "ThemeToggle", "UserAvatar+name"],
      },
    },
    "componentVariants": {
      "Button": {
        "variants": ["primary", "secondary", "ghost", "danger"],
        "sizes": ["sm(34px)", "default(44px)", "lg(52px)"],
        "states": ["default", "hover(opacity:.85)", "pressed(scale:.97)", "focus(ring 3px)", "disabled(opacity:.35)"],
        "props": ["children", "variant", "size", "icon", "loading", "disabled"],
      },
      "Badge": {
        "variants": ["default", "success", "warning", "danger", "info"],
        "props": ["children", "variant"],
      },
      "Field": {
        "states": ["default", "hover", "focus(border primary + glow)", "error(border danger + glow)", "disabled"],
        "props": ["label", "placeholder", "value", "type", "error", "required"],
        "height": 48,
      },
      "Card": {
        "variants": ["default", "hover(border primary/30 + translateY -1px)", "interactive"],
        "props": ["children", "className", "onClick"],
        "padding": 24,
        "radius": 16,
      },
      "NavItem": {
        "states": ["default", "hover(bg card)", "active(bg primary/15 + text primary)", "expanded(accordion open)"],
        "props": ["id", "icon", "label", "badge", "subs", "active", "collapsed"],
      },
    },
    "accessibility": {
      "standard": "WCAG 2.1 AA",
      "contrastRatios": {
        "primary-on-background": "4.8:1",
        "text-on-card": "9.2:1",
        "muted-on-card": "4.5:1",
        "danger-on-card": "4.6:1",
        "success-on-card": "4.7:1",
      },
      "keyboard": ["Tab navigation", "Enter/Space activate", "Escape dismiss modals/drawers", "Arrow keys within menus"],
      "aria": ["role=navigation on sidebar", "aria-current=page on active nav", "aria-expanded on accordion items", "aria-label on icon-only buttons"],
      "focusVisible": "ring 2px offset 2px #5CA9C7/60",
      "minClickTarget": "44×44px",
    },
  };
  return JSON.stringify(spec, null, 2);
}

function buildComponentVariantsJSON(): string {
  const ts = new Date().toISOString();
  const variants = {
    "$schema": "https://scenario-builder.dev/component-variants/v1",
    "meta": { "product": "Scenario Builder", "version": "4.2.1", "exported": ts },
    "components": {
      "Button": {
        "description": "Primary interactive element. 3 sizes, 4 variants, 5 states.",
        "props": { "variant": ["primary","secondary","ghost","danger"], "size": ["sm","default","lg"], "icon": "ReactNode?", "loading": "boolean?", "disabled": "boolean?", "onClick": "function?" },
        "tokens": { "height-sm": "34px", "height-default": "44px", "height-lg": "52px", "padding-x": "20px", "radius": "12px", "font-size": "14px", "font-weight": "600" },
        "variants": {
          "primary":   { "background": "#5CA9C7", "color": "#161A1F", "hover": "opacity:.85", "pressed": "scale:.97" },
          "secondary": { "background": "#252C34", "color": "#E8EDF2", "border": "1px solid #323A44", "hover": "border-color:#4a5567" },
          "ghost":     { "background": "transparent", "color": "#A8B2BF", "hover": "bg:#252C34, color:#E8EDF2" },
          "danger":    { "background": "rgba(201,106,106,.15)", "color": "#C96A6A", "border": "1px solid rgba(201,106,106,.3)", "hover": "opacity:.85" },
        },
      },
      "Badge": {
        "description": "Compact status label. 5 semantic variants.",
        "props": { "variant": ["default","success","warning","danger","info"] },
        "tokens": { "padding": "3px 8px", "radius": "6px", "font-size": "12px", "font-weight": "600" },
        "variants": {
          "default": { "background": "#323A44",                   "color": "#A8B2BF" },
          "success": { "background": "rgba(79,167,106,.2)",       "color": "#4FA76A" },
          "warning": { "background": "rgba(212,168,94,.2)",       "color": "#D4A85E" },
          "danger":  { "background": "rgba(201,106,106,.2)",      "color": "#C96A6A" },
          "info":    { "background": "rgba(92,169,199,.2)",       "color": "#5CA9C7" },
        },
      },
      "Field": {
        "description": "Labeled text input. Label always sits above field.",
        "props": { "label": "string", "placeholder": "string?", "value": "string", "type": "string?", "error": "string?", "required": "boolean?" },
        "tokens": { "height": "48px", "padding-x": "16px", "radius": "12px", "font-size": "14px", "background": "#252C34", "border-default": "#323A44", "border-focus": "#5CA9C7", "border-error": "#C96A6A", "shadow-focus": "0 0 0 3px rgba(92,169,199,.15)", "shadow-error": "0 0 0 3px rgba(201,106,106,.15)" },
      },
      "Sidebar": {
        "description": "Collapsible left nav. Accordion sub-items per section.",
        "tokens": { "width": "280px", "collapsed": "88px", "background": "#1A2027", "border": "#323A44" },
        "collapseSpring": { "stiffness": 280, "damping": 28 },
        "navItemStates": {
          "default": { "background": "transparent", "color": "#7B8794" },
          "hover":   { "background": "#252C34", "color": "#E8EDF2" },
          "active":  { "background": "rgba(92,169,199,.15)", "color": "#5CA9C7" },
        },
        "accordionAnimation": { "height": "0→auto", "opacity": "0→1", "duration": "200ms", "easing": "ease-out" },
      },
      "TopBar": {
        "description": "Fixed top navigation bar.",
        "tokens": { "height": "72px", "background": "#1D232A", "border-bottom": "#323A44" },
        "elements": ["SearchBar(240px)", "NotificationBell", "ThemeToggle", "UserAvatar"],
      },
      "Card": {
        "description": "Content container. Hover lifts border opacity.",
        "tokens": { "background": "#252C34", "border": "#323A44", "radius": "16px", "padding": "24px" },
        "hoverState": { "border": "rgba(92,169,199,.3)", "transform": "translateY(-1px)", "duration": "200ms" },
      },
      "Modal": {
        "description": "Center-anchored dialog. Spring scale-in from 0.95.",
        "tokens": { "max-width": "520px", "background": "#1D232A", "border": "#323A44", "radius": "20px", "overlay": "rgba(0,0,0,.6)", "blur": "8px" },
        "animation": { "enter": { "scale": "0.95→1", "y": "12→0", "spring": { "stiffness": 320, "damping": 24 } }, "exit": { "scale": "1→0.95", "y": "0→12", "duration": "150ms" } },
      },
      "Drawer": {
        "description": "Right-anchored panel. Spring slide-in from x=width.",
        "variants": { "pdf-preview": { "width": 680 } },
        "animation": { "enter": { "x": "width→0", "spring": { "stiffness": 320, "damping": 30 } }, "exit": { "x": "0→width", "duration": "280ms", "easing": "ease-in" } },
      },
      "StepWizard": {
        "description": "8-step horizontal stepper for Scenario Creation.",
        "props": { "currentStep": "1-8", "steps": "StepConfig[]", "onNext": "fn", "onBack": "fn", "onSaveDraft": "fn" },
        "tokens": { "connector-color": "#323A44", "active-color": "#5CA9C7", "complete-color": "#4FA76A" },
        "transition": { "type": "slide-horizontal", "direction": "depends-on-direction", "duration": "300ms", "easing": "cubic-bezier(0.4,0,0.2,1)" },
      },
      "DataTable": {
        "description": "Striped, sortable, row-action table.",
        "tokens": { "header-background": "#252C34", "row-hover": "#1D232A", "border": "#323A44", "header-font-size": "10px", "header-font-weight": "700", "header-letter-spacing": ".1em" },
        "features": ["sorting", "row-actions", "checkbox-select", "pagination", "search"],
      },
      "Toast": {
        "description": "Sonner-powered toast notifications. 4 semantic variants.",
        "position": "bottom-right",
        "variants": ["success(#4FA76A)", "error(#C96A6A)", "warning(#D4A85E)", "info(#5CA9C7)"],
        "duration": "4000ms",
        "animation": { "enter": "slide-up + fade", "exit": "fade + scale-down" },
      },
      "ClassificationBanner": {
        "description": "Full-width document classification bar.",
        "variants": {
          "UNCLASSIFIED":    { "background": "#4FA76A", "color": "#161A1F" },
          "CONFIDENTIAL":    { "background": "#6E8FB8", "color": "#ffffff" },
          "SECRET":          { "background": "#D4A85E", "color": "#161A1F" },
          "TOP SECRET":      { "background": "#C96A6A", "color": "#ffffff" },
          "TOP SECRET // SCI":{ "background": "#8B4A4A", "color": "#ffffff" },
        },
      },
    },
  };
  return JSON.stringify(variants, null, 2);
}

function ExportModal({ onClose }: { onClose: () => void }) {
  const [downloaded, setDownloaded] = useState<Set<string>>(new Set());

  const files = [
    {
      title: "Design Tokens",
      desc: "W3C format · Figma Tokens Studio · all color, type, spacing, motion",
      ext: ".json",
      icon: <Tag size={17} />,
      color: "#5CA9C7",
      generate: () => buildTokensJSON(),
      filename: "scenario-builder-tokens.json",
      mime: "application/json",
      tag: "Figma Tokens Studio",
    },
    {
      title: "CSS Variables",
      desc: "Custom properties + utility classes · drop into any codebase",
      ext: ".css",
      icon: <Layers size={17} />,
      color: "#6E8FB8",
      generate: () => buildCSSVars(),
      filename: "scenario-builder-tokens.css",
      mime: "text/css",
      tag: "Web",
    },
    {
      title: "Prototype Flow Spec",
      desc: "All screens, interactions, animations, transitions — structured JSON",
      ext: ".json",
      icon: <Navigation size={17} />,
      color: "#D4A85E",
      generate: () => buildPrototypeSpec(),
      filename: "scenario-builder-prototype-spec.json",
      mime: "application/json",
      tag: "Prototype",
    },
    {
      title: "Component Variants",
      desc: "All component props, states, tokens, animation specs",
      ext: ".json",
      icon: <Layers size={17} />,
      color: "#4FA76A",
      generate: () => buildComponentVariantsJSON(),
      filename: "scenario-builder-components.json",
      mime: "application/json",
      tag: "Dev Handoff",
    },
    {
      title: "HTML Documentation",
      desc: "Self-contained visual reference with colors, type, prototypes, animations",
      ext: ".html",
      icon: <Globe size={17} />,
      color: "#C96A6A",
      generate: () => buildHTMLDoc(),
      filename: "scenario-builder-design-system.html",
      mime: "text/html",
      tag: "Reference",
    },
  ];

  const doDownload = (f: typeof files[0]) => {
    downloadFile(f.generate(), f.filename, f.mime);
    setDownloaded(d => new Set([...d, f.title]));
    toast.success(`${f.filename} downloaded`);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center"
      onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
      <motion.div
        initial={{ scale: 0.95, y: 16 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95, y: 16 }}
        transition={{ type: "spring", damping: 24, stiffness: 300 }}
        onClick={e => e.stopPropagation()}
        className="relative bg-muted border border-border rounded-2xl w-[580px] max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-border bg-muted shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center">
              <Download size={20} className="text-primary" />
            </div>
            <div>
              <p className="text-sm font-bold text-foreground">Export Figma Design Package</p>
              <p className="text-xs text-muted-foreground">Tokens · Prototypes · Component specs · Animations · Documentation</p>
            </div>
          </div>
          <button onClick={onClose}
            className="w-8 h-8 rounded-lg bg-card border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
            <X size={15} />
          </button>
        </div>

        {/* Files list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {files.map(f => {
            const done = downloaded.has(f.title);
            return (
              <button key={f.title}
                onClick={() => doDownload(f)}
                className="w-full flex items-center gap-4 p-4 bg-card hover:bg-muted border rounded-xl transition-all text-left group"
                style={{ borderColor: done ? `${f.color}40` : "#323A44" }}>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0 transition-all"
                  style={{ background: done ? `${f.color}25` : `${f.color}18`, color: f.color }}>
                  {done ? <Check size={17} /> : f.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <p className="text-sm font-semibold text-foreground">{f.title}</p>
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded"
                      style={{ background: `${f.color}20`, color: f.color }}>{f.tag}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{f.desc}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-xs font-mono px-2 py-0.5 rounded border"
                    style={{ background: `${f.color}10`, color: f.color, borderColor: `${f.color}25` }}>{f.ext}</span>
                  <Download size={14} className="transition-colors"
                    style={{ color: done ? f.color : "#7B8794" }} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Download all */}
        <div className="px-4 pb-4 pt-2 border-t border-border space-y-2 shrink-0">
          <button
            onClick={() => {
              files.forEach((f, i) => setTimeout(() => doDownload(f), i * 250));
              setTimeout(() => toast.success("All 5 design files downloaded"), 100);
            }}
            className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/85 active:scale-95 transition-all">
            <Download size={16} />
            Download All 5 Files
          </button>
          <div className="flex items-center justify-between">
            <p className="text-[10px] text-muted-foreground">
              ITAR Controlled · Scenario Builder v4.2.1
            </p>
            <p className="text-[10px] text-muted-foreground">
              {downloaded.size}/{files.length} downloaded
            </p>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function ComponentLibrary() {
  const [activeSection, setActiveSection] = useState("colors");
  const [exportOpen, setExportOpen] = useState(false);
  const [progressVal, setProgressVal] = useState(68);

  const sections = [
    { id: "colors", label: "Color Tokens" },
    { id: "typography", label: "Typography" },
    { id: "spacing", label: "Spacing & Radius" },
    { id: "buttons", label: "Buttons" },
    { id: "inputs", label: "Form Controls" },
    { id: "badges", label: "Badges & Tags" },
    { id: "cards", label: "Cards & Surfaces" },
    { id: "feedback", label: "Feedback" },
    { id: "data", label: "Data Display" },
    { id: "navigation", label: "Navigation" },
    { id: "icons", label: "Icon Set" },
  ];

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Sticky section nav */}
      <aside className="w-44 shrink-0 border-r border-border py-4 px-2.5 overflow-y-auto bg-muted">
        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider px-2 mb-3">Sections</p>
        {sections.map(s => (
          <a key={s.id} href={`#${s.id}`} onClick={() => setActiveSection(s.id)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium mb-0.5 transition-colors
              ${activeSection === s.id ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-card"}`}>
            {s.label}
          </a>
        ))}
        <div className="mt-4 mx-2 pt-4 border-t border-border">
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-2">Export</p>
          <button onClick={() => setExportOpen(true)}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium bg-primary/15 text-primary hover:bg-primary/25 transition-colors">
            <Download size={12} />Download Kit
          </button>
        </div>
      </aside>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-8 space-y-14">

        {/* ── Colors ── */}
        <Section title="Color Tokens" id="colors">
          <div className="grid grid-cols-7 gap-3">
            {COLOR_TOKENS.map(c => (
              <div key={c.name} className="flex flex-col gap-2">
                <div className="w-full aspect-square rounded-xl border border-border shadow-sm"
                  style={{ background: c.hex }} />
                <div>
                  <p className="text-xs font-semibold text-foreground truncate">{c.name}</p>
                  <p className="text-[10px] font-mono text-primary">{c.hex}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{c.role}</p>
                </div>
              </div>
            ))}
          </div>
          {/* Gradient ramps */}
          <div className="mt-6 space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Opacity Ramps</p>
            {[
              { label: "Primary", hex: "#5CA9C7" },
              { label: "Success", hex: "#4FA76A" },
              { label: "Danger", hex: "#C96A6A" },
            ].map(r => (
              <div key={r.label} className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground w-16">{r.label}</span>
                <div className="flex gap-1.5 flex-1">
                  {[1, 0.8, 0.6, 0.4, 0.2, 0.12, 0.08].map(o => (
                    <div key={o} className="flex-1 h-8 rounded-lg border border-border"
                      style={{ background: r.hex, opacity: o }} />
                  ))}
                </div>
                <div className="flex gap-1.5 text-[10px] text-muted-foreground font-mono">
                  {["100", "80", "60", "40", "20", "12", "8"].map(v => (
                    <span key={v} className="w-7 text-center">{v}%</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* ── Typography ── */}
        <Section title="Typography" id="typography">
          <div className="space-y-1 bg-muted border border-border rounded-xl overflow-hidden">
            {TYPE_SCALE.map((t, i) => (
              <div key={t.name}
                className={`flex items-baseline gap-6 px-6 py-4 ${i < TYPE_SCALE.length - 1 ? "border-b border-border" : ""}`}>
                <div className="w-32 shrink-0">
                  <p className="text-xs font-semibold text-muted-foreground">{t.name}</p>
                  <p className="text-[10px] font-mono text-primary mt-0.5">{t.size} / {t.weight}</p>
                </div>
                <p className="text-foreground flex-1"
                  style={{ fontSize: `min(${t.size}, 28px)`, fontWeight: parseInt(t.weight) }}>
                  The quick brown fox
                </p>
                <span className="text-[10px] text-muted-foreground shrink-0 hidden lg:block">{t.usage}</span>
              </div>
            ))}
          </div>
          {/* Mono + Label */}
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-3">Monospace — Data / Coords</p>
              <p className="font-mono text-primary text-sm">37°14′06″N 115°48′40″W</p>
              <p className="font-mono text-dim text-xs mt-1.5">T+04:32:11 · HDG 247° · SPD 18kts</p>
            </div>
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-3">Label Styles</p>
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">FIELD LABEL — 10px / 700 / CAPS</p>
              <p className="text-xs font-semibold text-dim uppercase tracking-wide mb-2">Section Header — 12px / 600</p>
              <p className="text-sm font-medium text-foreground">Body Medium — 14px / 500</p>
            </div>
          </div>
        </Section>

        {/* ── Spacing ── */}
        <Section title="Spacing & Radius" id="spacing">
          <div className="grid grid-cols-2 gap-6">
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">8-Point Spacing Scale</p>
              <div className="space-y-3">
                {SPACING.map(s => (
                  <div key={s} className="flex items-center gap-3">
                    <span className="text-xs font-mono text-primary w-8">{s}px</span>
                    <div className="h-5 bg-primary/30 border border-primary/50 rounded" style={{ width: s * 2 }} />
                    <span className="text-xs text-muted-foreground">{s / 4} × 4</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Border Radius</p>
              <div className="space-y-4">
                {[
                  { label: "sm — 4px", r: "4px", use: "Tags, chips" },
                  { label: "md — 8px", r: "8px", use: "Inputs, small buttons" },
                  { label: "lg — 12px", r: "12px", use: "Base radius (--radius)" },
                  { label: "xl — 16px", r: "16px", use: "Cards, modals" },
                  { label: "2xl — 20px", r: "20px", use: "Large cards, panels" },
                  { label: "full — 9999px", r: "9999px", use: "Pills, avatars, toggles" },
                ].map(r => (
                  <div key={r.label} className="flex items-center gap-4">
                    <div className="w-14 h-10 bg-primary/20 border border-primary/40"
                      style={{ borderRadius: r.r }} />
                    <div>
                      <p className="text-xs font-mono text-foreground">{r.label}</p>
                      <p className="text-[10px] text-muted-foreground">{r.use}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Section>

        {/* ── Buttons ── */}
        <Section title="Buttons" id="buttons">
          <div className="space-y-6">
            {/* Variants */}
            <div className="bg-muted border border-border rounded-xl p-6">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-5">Variants</p>
              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex flex-col items-center gap-2">
                  <Btn>Primary</Btn>
                  <span className="text-[10px] text-muted-foreground">primary</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <Btn variant="secondary">Secondary</Btn>
                  <span className="text-[10px] text-muted-foreground">secondary</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <Btn variant="ghost">Ghost</Btn>
                  <span className="text-[10px] text-muted-foreground">ghost</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <Btn variant="danger">Danger</Btn>
                  <span className="text-[10px] text-muted-foreground">danger</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <Btn disabled>Disabled</Btn>
                  <span className="text-[10px] text-muted-foreground">disabled</span>
                </div>
              </div>
            </div>
            {/* Sizes */}
            <div className="bg-muted border border-border rounded-xl p-6">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-5">Sizes</p>
              <div className="flex flex-wrap gap-4 items-end">
                <div className="flex flex-col items-center gap-2">
                  <Btn size="sm">Small — 32h</Btn>
                  <span className="text-[10px] text-muted-foreground">sm / 32px</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <Btn size="md">Medium — 40h</Btn>
                  <span className="text-[10px] text-muted-foreground">md / 40px</span>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <Btn size="lg">Large — 48h</Btn>
                  <span className="text-[10px] text-muted-foreground">lg / 48px</span>
                </div>
              </div>
            </div>
            {/* With icons */}
            <div className="bg-muted border border-border rounded-xl p-6">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-5">With Icons</p>
              <div className="flex flex-wrap gap-4 items-center">
                <Btn icon={<Plus size={14} />}>Add Scenario</Btn>
                <Btn variant="secondary" icon={<Download size={14} />}>Export PDF</Btn>
                <Btn variant="danger" icon={<Trash2 size={14} />}>Delete</Btn>
                <Btn variant="ghost" icon={<ArrowRight size={14} />}>Continue</Btn>
                <Btn icon={<Play size={14} />}>Generate</Btn>
                <Btn variant="secondary" icon={<Save size={14} />}>Save Draft</Btn>
              </div>
            </div>
            {/* Icon-only */}
            <div className="bg-muted border border-border rounded-xl p-6">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-5">Icon-Only Buttons</p>
              <div className="flex gap-3 flex-wrap items-center">
                {[
                  { ic: <Plus size={16} />, bg: "bg-primary", c: "text-primary-foreground" },
                  { ic: <Edit2 size={16} />, bg: "bg-card border border-border", c: "text-dim" },
                  { ic: <Trash2 size={16} />, bg: "bg-destructive/20 border border-destructive/30", c: "text-destructive" },
                  { ic: <Download size={16} />, bg: "bg-card border border-border", c: "text-dim" },
                  { ic: <RefreshCw size={16} />, bg: "bg-card border border-border", c: "text-dim" },
                  { ic: <Eye size={16} />, bg: "bg-card border border-border", c: "text-dim" },
                ].map((b, i) => (
                  <button key={i} className={`w-9 h-9 rounded-xl flex items-center justify-center ${b.bg} ${b.c} hover:opacity-80 transition-opacity`}>{b.ic}</button>
                ))}
              </div>
            </div>
          </div>
        </Section>

        {/* ── Inputs ── */}
        <Section title="Form Controls" id="inputs">
          <div className="grid grid-cols-2 gap-5">
            {/* Text inputs */}
            <div className="bg-muted border border-border rounded-xl p-5 space-y-4">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Text Inputs — 48px height</p>
              <Field label="Default" placeholder="Placeholder text" />
              <Field label="With Icon" placeholder="Search scenarios..." icon={<Search size={14} />} />
              <Field label="Email" type="email" placeholder="operator@domain.mil" icon={<User size={14} />} />
              <Field label="Password" type="password" placeholder="••••••••" icon={<Lock size={14} />} />
            </div>
            {/* Other controls */}
            <div className="bg-muted border border-border rounded-xl p-5 space-y-4">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Other Controls</p>
              <Sel label="Select / Dropdown" options={[
                { label: "Maritime Operation", value: "maritime" },
                { label: "Aviation Operation", value: "aviation" },
                { label: "Ground Operation", value: "ground" },
              ]} />
              <Field label="Textarea" placeholder="Enter mission description..." rows={3} />
              <div className="space-y-2">
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Checkbox & Radio</p>
                <div className="flex flex-col gap-2">
                  {["Remember this device", "Enable notifications", "Auto-save drafts"].map((l, i) => (
                    <label key={l} className="flex items-center gap-2.5 cursor-pointer">
                      <input type="checkbox" defaultChecked={i === 0} className="w-4 h-4 rounded accent-[#5CA9C7]" />
                      <span className="text-sm text-dim">{l}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            {/* Toggle */}
            <div className="bg-muted border border-border rounded-xl p-5 col-span-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Toggles & Range</p>
              <div className="flex gap-8 flex-wrap items-start">
                <div className="flex flex-col gap-3">
                  {[
                    { label: "System Active", on: true },
                    { label: "2FA Enabled", on: true },
                    { label: "Dark Theme", on: true },
                    { label: "Auto-Archive", on: false },
                  ].map(t => (
                    <div key={t.label} className="flex items-center gap-3">
                      <div className={`w-10 h-5 rounded-full relative ${t.on ? "bg-primary" : "bg-border"}`}>
                        <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-all ${t.on ? "right-0.5" : "left-0.5"}`} />
                      </div>
                      <span className="text-sm text-dim">{t.label}</span>
                    </div>
                  ))}
                </div>
                <div className="flex-1 space-y-4 min-w-48">
                  {[
                    { label: "Wind Speed (kts)", val: 28, max: 60 },
                    { label: "Visibility (nm)", val: 12, max: 20 },
                    { label: "Temperature (°C)", val: 22, max: 50 },
                  ].map(r => (
                    <div key={r.label}>
                      <div className="flex justify-between mb-1.5">
                        <span className="text-xs text-dim">{r.label}</span>
                        <span className="text-xs font-mono text-primary">{r.val}</span>
                      </div>
                      <input type="range" min={0} max={r.max} defaultValue={r.val} className="w-full accent-[#5CA9C7]" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </Section>

        {/* ── Badges ── */}
        <Section title="Badges & Tags" id="badges">
          <div className="space-y-5">
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Status Badges</p>
              <div className="flex flex-wrap gap-3">
                <div className="flex flex-col items-center gap-1.5">
                  <Badge>Default</Badge>
                  <span className="text-[10px] text-muted-foreground">default</span>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                  <Badge variant="success">Active</Badge>
                  <span className="text-[10px] text-muted-foreground">success</span>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                  <Badge variant="warning">Review</Badge>
                  <span className="text-[10px] text-muted-foreground">warning</span>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                  <Badge variant="danger">Critical</Badge>
                  <span className="text-[10px] text-muted-foreground">danger</span>
                </div>
                <div className="flex flex-col items-center gap-1.5">
                  <Badge variant="info">In Progress</Badge>
                  <span className="text-[10px] text-muted-foreground">info</span>
                </div>
              </div>
            </div>
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Classification Tags</p>
              <div className="flex flex-wrap gap-3">
                {[
                  { label: "UNCLASSIFIED", bg: "#4FA76A", text: "white" },
                  { label: "CONFIDENTIAL", bg: "#6E8FB8", text: "white" },
                  { label: "SECRET", bg: "#D4A85E", text: "#161A1F" },
                  { label: "TOP SECRET", bg: "#C96A6A", text: "white" },
                  { label: "TOP SECRET // SCI", bg: "#8B4A4A", text: "white" },
                ].map(c => (
                  <span key={c.label}
                    className="inline-flex items-center px-3 py-1 rounded-md text-xs font-bold tracking-wide"
                    style={{ background: c.bg, color: c.text }}>
                    {c.label}
                  </span>
                ))}
              </div>
            </div>
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Domain Tags & Counters</p>
              <div className="flex flex-wrap gap-3 items-center">
                {["Maritime", "Aviation", "Ground", "Space", "Cyber", "EW"].map(d => (
                  <span key={d} className="inline-flex items-center px-3 py-1.5 rounded-xl text-xs font-medium bg-card border border-border text-dim">{d}</span>
                ))}
                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-[10px] font-bold">4</span>
                <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-destructive text-white text-[10px] font-bold">!</span>
                <span className="inline-flex items-center justify-center w-5 h-5 rounded-full bg-warning text-primary-foreground text-[10px] font-bold">3</span>
              </div>
            </div>
          </div>
        </Section>

        {/* ── Cards ── */}
        <Section title="Cards & Surfaces" id="cards">
          <div className="grid grid-cols-3 gap-4">
            {/* Default card */}
            <SCard className="p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-3">Default Card</p>
              <p className="text-lg font-bold text-foreground">247</p>
              <p className="text-xs text-muted-foreground mt-0.5">Total Scenarios</p>
              <div className="mt-3 pt-3 border-t border-border flex items-center gap-2">
                <Badge variant="success">+12%</Badge>
                <span className="text-xs text-muted-foreground">vs last month</span>
              </div>
            </SCard>
            {/* Metric card */}
            <SCard className="p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-3">Metric Card</p>
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Activity size={18} className="text-primary" />
                </div>
                <div>
                  <p className="text-xl font-bold text-foreground">94.2%</p>
                  <p className="text-xs text-muted-foreground">Completion Rate</p>
                </div>
              </div>
              <div className="h-1.5 bg-card rounded-full overflow-hidden">
                <div className="h-full bg-success rounded-full" style={{ width: "94%" }} />
              </div>
            </SCard>
            {/* Entity card */}
            <SCard className="p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-3">Entity Card</p>
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-muted border border-border flex items-center justify-center text-primary shrink-0">
                  <Ship size={18} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">USS Gerald R. Ford</p>
                  <p className="text-xs text-muted-foreground">Aircraft Carrier · CVN-78</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Badge variant="success">Active</Badge>
                <Badge>Friendly</Badge>
                <Badge variant="info">Maritime</Badge>
              </div>
            </SCard>
            {/* Alert surface */}
            <SCard className="p-5 col-span-3">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Surface Hierarchy</p>
              <div className="flex gap-3">
                {[
                  { label: "Background", bg: "#161A1F" },
                  { label: "Sidebar", bg: "#1A2027" },
                  { label: "Surface", bg: "#1D232A" },
                  { label: "Card", bg: "#252C34" },
                  { label: "Hover", bg: "#2d3640" },
                  { label: "Border", bg: "#323A44" },
                ].map(s => (
                  <div key={s.label} className="flex-1 text-center">
                    <div className="w-full h-14 rounded-xl border border-border" style={{ background: s.bg }} />
                    <p className="text-[10px] text-muted-foreground mt-1.5">{s.label}</p>
                    <p className="text-[10px] font-mono text-primary">{s.bg}</p>
                  </div>
                ))}
              </div>
            </SCard>
          </div>
        </Section>

        {/* ── Feedback ── */}
        <Section title="Feedback" id="feedback">
          <div className="space-y-5">
            {/* Alerts */}
            <div className="bg-muted border border-border rounded-xl p-5 space-y-3">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Alert / Inline Feedback</p>
              {[
                { type: "success", icon: <Check size={14} />, title: "Scenario Generated", msg: "Operation Neptune Strike has been compiled and is ready for deployment.", border: "#4FA76A", bg: "#4FA76A" },
                { type: "warning", icon: <AlertTriangle size={14} />, title: "Validation Warning", msg: "4 entities are missing required position data. Configure before generating.", border: "#D4A85E", bg: "#D4A85E" },
                { type: "danger", icon: <AlertTriangle size={14} />, title: "Generation Failed", msg: "Insufficient entities to form valid relationships. Add at least 2 entities.", border: "#C96A6A", bg: "#C96A6A" },
                { type: "info", icon: <Info size={14} />, title: "Review Required", msg: "This scenario is pending commanding officer authorization before deployment.", border: "#5CA9C7", bg: "#5CA9C7" },
              ].map(a => (
                <div key={a.type} className="flex gap-3 p-3.5 rounded-xl border"
                  style={{ borderColor: `${a.border}30`, background: `${a.bg}08` }}>
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                    style={{ background: `${a.bg}20`, color: a.bg }}>
                    {a.icon}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{a.title}</p>
                    <p className="text-xs text-dim mt-0.5">{a.msg}</p>
                  </div>
                </div>
              ))}
            </div>
            {/* Progress */}
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-5">Progress Indicators</p>
              <div className="space-y-4">
                {[
                  { label: "Scenario Generation", val: progressVal, color: "#5CA9C7" },
                  { label: "Storage Capacity", val: 78, color: "#D4A85E" },
                  { label: "Mission Completion", val: 94, color: "#4FA76A" },
                  { label: "Critical Threshold", val: 95, color: "#C96A6A" },
                ].map(p => (
                  <div key={p.label}>
                    <div className="flex justify-between mb-1.5">
                      <span className="text-xs text-dim">{p.label}</span>
                      <span className="text-xs font-mono" style={{ color: p.color }}>{p.val}%</span>
                    </div>
                    <div className="h-2 bg-card rounded-full overflow-hidden">
                      <motion.div className="h-full rounded-full" style={{ background: p.color, width: `${p.val}%` }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <input type="range" min={0} max={100} value={progressVal}
                  onChange={e => setProgressVal(Number(e.target.value))}
                  className="w-full accent-[#5CA9C7]" />
                <p className="text-[10px] text-muted-foreground mt-1">Drag to preview progress states</p>
              </div>
            </div>
            {/* Toast trigger */}
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Toast Notifications</p>
              <div className="flex gap-3 flex-wrap">
                {[
                  { label: "Success", fn: () => toast.success("Scenario generated successfully!"), v: "bg-success/20 text-success border border-success/30" },
                  { label: "Error", fn: () => toast.error("Generation failed. Check entity data."), v: "bg-destructive/20 text-destructive border border-destructive/30" },
                  { label: "Warning", fn: () => toast.warning("Storage at 85% capacity."), v: "bg-warning/20 text-warning border border-warning/30" },
                  { label: "Info", fn: () => toast.info("Review requested by CMO."), v: "bg-primary/20 text-primary border border-primary/30" },
                ].map(t => (
                  <button key={t.label} onClick={t.fn}
                    className={`px-4 py-2 rounded-xl text-sm font-medium ${t.v} hover:opacity-80 transition-opacity`}>
                    {t.label} Toast
                  </button>
                ))}
              </div>
              {/* Static toast previews */}
              <div className="mt-4 space-y-2">
                {[
                  { icon: <Check size={14} />, msg: "Scenario Neptune Strike generated.", sub: "Just now", col: "#4FA76A" },
                  { icon: <AlertTriangle size={14} />, msg: "Validation warning in Desert Shield.", sub: "2 min ago", col: "#D4A85E" },
                ].map((n, i) => (
                  <div key={i} className="flex items-center gap-3 px-4 py-3 bg-card border border-border rounded-xl">
                    <span style={{ color: n.col }}>{n.icon}</span>
                    <div className="flex-1">
                      <p className="text-sm text-foreground">{n.msg}</p>
                      <p className="text-[10px] text-muted-foreground">{n.sub}</p>
                    </div>
                    <button className="text-muted-foreground hover:text-foreground"><X size={14} /></button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Section>

        {/* ── Data Display ── */}
        <Section title="Data Display" id="data">
          <div className="space-y-5">
            {/* Table */}
            <SCard className="overflow-hidden p-0">
              <div className="px-5 py-4 border-b border-border flex items-center justify-between">
                <p className="text-sm font-semibold text-foreground">Data Table</p>
                <div className="flex gap-2">
                  <Badge variant="info">7 rows</Badge>
                  <Btn variant="secondary" size="sm" icon={<Download size={12} />}>Export</Btn>
                </div>
              </div>
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    {["Name", "Type", "Status", "Priority", "Entities"].map(h => (
                      <th key={h} className="px-4 py-2.5 text-left text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {LIB_SCENARIOS.slice(0, 4).map((s, i) => (
                    <tr key={s.id} className={`hover:bg-muted transition-colors ${i < 3 ? "border-b border-border" : ""}`}>
                      <td className="px-4 py-3 text-sm font-medium text-foreground">{s.name}</td>
                      <td className="px-4 py-3 text-xs text-dim">{s.type}</td>
                      <td className="px-4 py-3"><Badge variant={s.status === "active" ? "success" : s.status === "complete" ? "info" : "warning"}>{s.status}</Badge></td>
                      <td className="px-4 py-3"><Badge variant={s.priority === "Critical" ? "danger" : s.priority === "High" ? "warning" : "default"}>{s.priority}</Badge></td>
                      <td className="px-4 py-3 text-xs text-dim">{s.entities}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </SCard>
            {/* Stepper */}
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-5">Stepper / Progress Steps</p>
              <div className="flex items-center">
                {["General", "Environment", "Assets", "Configure", "Relationships", "Timeline", "Review", "Generate"].map((s, i) => (
                  <div key={s} className="flex items-center flex-1">
                    <div className="flex flex-col items-center gap-1.5">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold
                        ${i < 3 ? "bg-primary/25 text-primary border border-primary/40"
                          : i === 3 ? "bg-primary text-primary-foreground"
                          : "bg-card text-muted-foreground border border-border"}`}>
                        {i < 3 ? <Check size={12} /> : i + 1}
                      </div>
                      <span className="text-[10px] text-muted-foreground hidden lg:block whitespace-nowrap">{s}</span>
                    </div>
                    {i < 7 && <div className={`flex-1 h-px mx-1 ${i < 3 ? "bg-primary/40" : "bg-border"}`} />}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Section>

        {/* ── Navigation ── */}
        <Section title="Navigation" id="navigation">
          <div className="grid grid-cols-2 gap-5">
            {/* Tabs */}
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Tab Bar</p>
              <div className="flex gap-1 bg-card p-1 rounded-xl mb-4">
                {["Overview", "Entities", "Timeline"].map((t, i) => (
                  <button key={t}
                    className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${i === 0 ? "bg-muted text-foreground shadow-sm" : "text-muted-foreground hover:text-dim"}`}>
                    {t}
                  </button>
                ))}
              </div>
              <div className="flex gap-1">
                {["All", "Active", "Drafts", "Complete", "Archived"].map((t, i) => (
                  <button key={t}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors
                      ${i === 0 ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                    {t}
                  </button>
                ))}
              </div>
            </div>
            {/* Breadcrumb */}
            <div className="bg-muted border border-border rounded-xl p-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Breadcrumb</p>
              <div className="flex items-center gap-1.5 text-sm">
                <span className="text-primary hover:underline cursor-pointer">Dashboard</span>
                <ChevronRight size={14} className="text-muted-foreground" />
                <span className="text-dim hover:underline cursor-pointer">Scenario Library</span>
                <ChevronRight size={14} className="text-muted-foreground" />
                <span className="text-foreground">Neptune Strike</span>
              </div>
              <div className="mt-4 flex items-center gap-1.5 text-sm">
                <Home size={14} className="text-primary" />
                <ChevronRight size={12} className="text-muted-foreground" />
                <span className="text-dim">Assets</span>
                <ChevronRight size={12} className="text-muted-foreground" />
                <span className="text-dim">Maritime</span>
                <ChevronRight size={12} className="text-muted-foreground" />
                <span className="text-foreground">USS Gerald R. Ford</span>
              </div>
            </div>
            {/* Search */}
            <div className="bg-muted border border-border rounded-xl p-5 col-span-2">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider mb-4">Search Bar Variants</p>
              <div className="flex flex-col gap-3">
                <div className="relative">
                  <Search size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input placeholder="Search scenarios, assets, reports..."
                    className="w-full h-10 bg-card border border-border rounded-lg pl-9 pr-4 text-sm text-foreground placeholder-muted-foreground outline-none focus:border-primary" />
                </div>
                <div className="relative">
                  <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <input placeholder="Global search — press ⌘K to open"
                    className="w-full h-12 bg-card border border-primary/40 rounded-xl pl-11 pr-4 text-sm text-foreground placeholder-muted-foreground outline-none ring-1 ring-primary/20" />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] font-mono text-muted-foreground bg-muted border border-border px-2 py-0.5 rounded">⌘K</span>
                </div>
              </div>
            </div>
          </div>
        </Section>

        {/* ── Icons ── */}
        <Section title="Icon Set" id="icons">
          <div className="bg-muted border border-border rounded-xl p-5">
            <div className="flex items-center justify-between mb-5">
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Lucide Icons — 20px / stroke-1.5 / used in app</p>
              <Badge variant="info">{ICON_SHOWCASE.length} icons</Badge>
            </div>
            <div className="grid grid-cols-10 gap-2">
              {ICON_SHOWCASE.map(({ icon, name }) => (
                <div key={name}
                  className="flex flex-col items-center gap-2 p-3 rounded-xl hover:bg-card transition-colors cursor-pointer group">
                  <span className="text-dim group-hover:text-primary transition-colors">{icon}</span>
                  <span className="text-[9px] text-muted-foreground text-center leading-tight">{name}</span>
                </div>
              ))}
            </div>
          </div>
        </Section>

        {/* Bottom padding */}
        <div className="h-8" />
      </div>

      {/* Export modal */}
      <AnimatePresence>
        {exportOpen && <ExportModal onClose={() => setExportOpen(false)} />}
      </AnimatePresence>
    </div>
  );
}

// ─── App Layout ───────────────────────────────────────────────────────────────

function AppLayout({ screen, onNav, onLogout }: {
  screen: AppScreen;
  onNav: (s: AppScreen) => void;
  onLogout: () => void;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  const closeMobile = () => setMobileOpen(false);

  return (
    <div className="w-full h-full flex bg-background overflow-hidden">
      {/* Desktop sidebar */}
      <div className="hidden md:flex h-full shrink-0">
        <Sidebar active={screen} onNav={onNav} collapsed={collapsed} onToggle={() => setCollapsed(c => !c)} />
      </div>

      {/* Mobile drawer overlay */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            key="mobile-overlay"
            className="md:hidden fixed inset-0 z-40"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={closeMobile} />
            <motion.div
              className="absolute inset-y-0 left-0 z-10"
              initial={{ x: -280 }} animate={{ x: 0 }} exit={{ x: -280 }}
              transition={{ type: "spring", stiffness: 320, damping: 30 }}
            >
              <Sidebar
                active={screen} onNav={(s) => { onNav(s); closeMobile(); }}
                collapsed={false} onToggle={() => {}}
                isMobile onMobileClose={closeMobile}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <TopBar screen={screen} onMenuOpen={() => setMobileOpen(true)} />
        <main className="flex-1 flex overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div key={screen}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              transition={{ duration: 0.12 }}
              className="flex-1 flex overflow-hidden min-w-0">
              {screen === "dashboard" && <Dashboard onNav={onNav} />}
              {screen === "create-scenario" && <CreateScenario onCancel={() => onNav("dashboard")} />}
              {screen === "scenario-library" && <ScenarioLibrary onNav={onNav} />}
              {screen === "asset-library" && <AssetLibrary />}
              {screen === "reports" && <Reports />}
              {screen === "notifications" && <NotificationsPage />}
              {screen === "settings" && <SettingsPage />}
              {screen === "profile" && <ProfilePage onLogout={onLogout} />}
              {screen === "help" && <HelpPage />}
              {screen === "component-library" && <ComponentLibrary />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [root, setRoot] = useState<RootScreen>("splash");
  const [appScreen, setAppScreen] = useState<AppScreen>("dashboard");
  const [theme, setTheme] = useState<Theme>("dark");

  const toggle = () => setTheme(t => t === "dark" ? "light" : "dark");

  useEffect(() => {
    document.documentElement.classList.toggle("light", theme === "light");
  }, [theme]);

  return (
    <ThemeCtx.Provider value={{ theme, toggle }}>
      <div className="w-full h-screen overflow-hidden bg-background transition-colors duration-300">
        <Toaster
          theme={theme}
          position="top-right"
          toastOptions={{
            style: {
              background: theme === "dark" ? "#252C34" : "#FFFFFF",
              border: theme === "dark" ? "1px solid #323A44" : "1px solid #C8D4DC",
              color: theme === "dark" ? "#E8EDF2" : "#1A2630",
            },
          }}
        />
        <AnimatePresence mode="wait">
          {root === "splash" && (
            <motion.div key="splash" className="w-full h-full" exit={{ opacity: 0 }} transition={{ duration: 0.5 }}>
              <SplashScreen onDone={() => setRoot("login")} />
            </motion.div>
          )}
          {root === "login" && (
            <motion.div key="login" className="w-full h-full" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <LoginScreen onLogin={() => setRoot("app")} onSignup={() => setRoot("signup")} />
            </motion.div>
          )}
          {root === "signup" && (
            <motion.div key="signup" className="w-full h-full" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <SignupScreen onBack={() => setRoot("login")} onDone={() => setRoot("app")} />
            </motion.div>
          )}
          {root === "app" && (
            <motion.div key="app" className="w-full h-full" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <AppLayout screen={appScreen} onNav={setAppScreen} onLogout={() => setRoot("login")} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </ThemeCtx.Provider>
  );
}
