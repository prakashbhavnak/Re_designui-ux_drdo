You are a Principal Product Designer at a world-class enterprise software company.

Design a complete, production-ready desktop web application (1440×1024) called "Scenario Builder", a professional platform used to create and manage simulation scenarios involving multiple assets such as ships, boats, aircraft, helicopters, drones, missiles, rockets, submarines, satellites, radars, sensors, and communication systems.

The product should feel like enterprise mission-planning software with excellent usability, accessibility, consistency, and scalability.

The design should never resemble a video game.

==================================================
GLOBAL DESIGN SYSTEM
==================================================

Desktop Frame
1440 × 1024

Responsive Grid
12 Columns

Margins
80px

Gutter
24px

Vertical spacing
24px

8-point spacing system

Corner Radius
12px

Cards
24px padding

Input Height
48px

Button Height
44px

Sidebar Width
280px

Collapsed Sidebar
88px

Top Navigation Height
72px

Right Panel Width
360px

Scrollbar
Thin

==================================================
TYPOGRAPHY
==================================================

Font
Inter

Display
36 Bold

Page Title
32 Bold

Section Heading
24 SemiBold

Card Title
18 SemiBold

Body
16 Regular

Small
14

Caption
12

Line Height
150%

==================================================
COLOR PALETTE
==================================================

Background
#161A1F

Sidebar
#1A2027

Surface
#1D232A

Cards
#252C34

Borders
#323A44

Primary
#5CA9C7

Secondary
#6E8FB8

Success
#4FA76A

Warning
#D4A85E

Danger
#C96A6A

Text
#E8EDF2

Secondary Text
#A8B2BF

Muted
#7B8794

No pure black.

No neon.

==================================================
AUTO LAYOUT RULES
==================================================

Everything uses Auto Layout.

Cards
Vertical

Gap
16

Padding
24

Sections
Gap
32

Buttons
Gap
12

Forms
Gap
24

Labels above fields

Consistent constraints

Responsive resizing

Reusable components

Variants

Design Tokens

Component Properties

==================================================
SCREEN 01
SPLASH
==================================================

Centered logo

Animated grid background

Subtle radar circles

Loading animation

Tagline

Progress indicator

==================================================
SCREEN 02
LOGIN
==================================================

Split layout

40/60

Left

Large aerospace illustration

Ocean

Aircraft

Satellite

Radar

World map grid

Right

Glass card

Width
420

Fields

Email

Password

Remember me

Forgot password

Primary button

Secondary button

Footer

==================================================
SCREEN 03
SIGN UP
==================================================

Same layout

Fields

Full Name

Organization

Email

Password

Confirm Password

Terms checkbox

Create Account

Already have account

==================================================
SCREEN 04
DASHBOARD
==================================================

Sidebar

280px

Logo

Navigation

Dashboard

Create Scenario

Scenario Library

Assets

Templates

Reports

Notifications

Settings

Profile

Help

Top Bar

Search

Notifications

Theme

User

Main Area

Quick Actions

Statistics

Recent Scenarios

Drafts

Recent Activity

Continue Editing

Mission Status

Charts

Storage

Right Panel

Notifications

Recent Changes

==================================================
SCREEN 05
CREATE SCENARIO
==================================================

Large stepper

1 General

2 Environment

3 Assets

4 Configure

5 Relationships

6 Timeline

7 Review

8 Generate

Top buttons

Save Draft

Cancel

Next

==================================================
SCREEN 06
GENERAL INFORMATION
==================================================

Two-column layout

Scenario Name

Mission Type

Mission Description

Classification

Location

Date

Time

Priority

Tags

Notes

==================================================
SCREEN 07
ENVIRONMENT
==================================================

Large cards

Ocean

Land

Mountain

Urban

Forest

Weather

Sea State

Wind

Visibility

Cloud

Temperature

Mini preview panel

==================================================
SCREEN 08
ADD ENTITIES
==================================================

Search

Filters

Category Tabs

Ships

Aircraft

Missiles

Rocket

Drone

Radar

Satellite

Submarine

Ground

Grid cards

Each card

Image

Icon

Description

Add Button

Hover State

==================================================
SCREEN 09
ENTITY DETAILS
==================================================

Dynamic Form

Accordion Sections

General

Position

Movement

Communication

Payload

Status

Notes

Sticky Save Button

Right Summary Panel

==================================================
SCREEN 10
ENTITY RELATIONSHIPS
==================================================

Interactive node graph

Drag connections

Attack

Support

Detection

Communication

Escort

Supply

Toolbar

Zoom

Undo

Redo

==================================================
SCREEN 11
MISSION TIMELINE
==================================================

Horizontal timeline

Mission phases

Events

Triggers

Dependencies

Drag and Drop

Event Details Drawer

==================================================
SCREEN 12
REVIEW
==================================================

Checklist

Validation

Mission Summary

Entity Summary

Timeline Summary

Warnings

Generate Button

==================================================
SCREEN 13
GENERATED SCENARIO
==================================================

Hero Card

Mission Overview

Timeline

Entities

Statistics

Export PDF

Export JSON

Duplicate

Delete

Edit

==================================================
SCREEN 14
SCENARIO LIBRARY
==================================================

Table

Grid Toggle

Search

Advanced Filters

Status

Last Modified

Owner

Duplicate

Delete

==================================================
SCREEN 15
ASSET LIBRARY
==================================================

Card Grid

Images

Metadata

Search

Filter

Upload

Preview Drawer

==================================================
SCREEN 16
REPORTS
==================================================

Analytics

Charts

Mission Count

Asset Usage

Completion Rate

Timeline

Export

==================================================
SCREEN 17
NOTIFICATIONS
==================================================

Inbox

Activity Feed

Comments

Mentions

Filters

==================================================
SCREEN 18
SETTINGS
==================================================

Profile

Security

Theme

Notifications

Storage

API

Preferences

==================================================
SCREEN 19
HELP
==================================================

Documentation

Tutorials

FAQ

Contact

Support Tickets

==================================================
SCREEN 20
PROFILE
==================================================

Avatar

Organization

Statistics

Recent Work

Preferences

Security

Logout

==================================================
COMPONENT LIBRARY
==================================================

Primary Button

Secondary Button

Ghost Button

Danger Button

Icon Button

Text Field

Dropdown

Search

Date Picker

Tabs

Accordion

Cards

Metric Cards

Charts

Tables

Toast

Modal

Drawer

Timeline

Node

Breadcrumb

Progress

Skeleton

Badges

==================================================
MICRO INTERACTIONS
==================================================

200ms easing

Card hover elevation

Button ripple

Sidebar animation

Smooth page transitions

Animated loading

Toast notifications

Skeleton loaders

==================================================
ACCESSIBILITY
==================================================

WCAG AA

Keyboard Navigation

Focus States

Color Safe

Readable Contrast

Large Click Targets

==================================================
FINAL RESULT
==================================================

Every screen should look like premium enterprise software used in aerospace organizations and command centers.

Maintain perfect spacing, alignment, hierarchy, consistency, responsiveness, reusable components, Auto Layout, Variables, Design Tokens, and component variants throughout the design.

The final design should be realistic enough that developers can directly build from it.